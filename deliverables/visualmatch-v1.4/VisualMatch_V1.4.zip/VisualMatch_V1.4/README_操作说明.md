# VisualMatch V1.4 操作说明

本程序以 RGB 定稿与 Illustrator 导出的 CMYK PNG 的实际像素 CIEDE2000 色差为依据，优化同屏视觉接近程度。保留 V1.3 已验证的副本创建、RGB→CMYK 菜单转换、AI 保存和 PNG 导出流程。不会保证超出 CMYK 色域的颜色完全还原。

**交付状态：代码、静态检查和本环境可执行测试已完成；Illustrator 2025 实机待验收。** 随包 `reference/02_optimized_CMYK.png` 是历史 V1.3 图，不是本次生成的 V1.4 成果。不要把它当作 V1.4 优化证明。真实 V1.4 的三图、可编辑 AI 和运行报告将在本机 Illustrator 执行后生成。

## 1. 准备

1. 将整个 ZIP 解压到一个可写的普通文件夹。保留 `src/`、`tools/`、`config.json` 相对位置，不要在 ZIP 内运行 JSX。避免同步软件正在改写的目录。
2. 需要 Adobe Illustrator 2025（29.x）及 **Python 3.12 64 位**。Node.js 只用于开发静态检查，不是设计师运行所必需。
3. 安装原稿使用的字体：`AdobeSongStd-Light`、`SourceHanSansCN-Bold`、`SourceHanSansCN-Medium`、`SourceHanSansCN-Regular`、`SourceHanSansJP-Bold`。字体未随包分发。按合法来源安装，不要用其他字体替换。若 Illustrator 打开原稿时提示缺字/缺字体，先解决再运行。
4. 在 Illustrator 打开 `reference/凝英降碳剂_V5_方案C_上移排版_可编辑_复制.ai`，确认 RGB、文字正确、无未保存修改。原稿旁目录须可写。未保存文档或非 RGB 文档会安全停止。
5. 保持 Illustrator 当前颜色设置，在一次任务内不要更换配置、切换预览策略或修改任何运行中的工作文档。本程序不切换系统/Illustrator ICC 设置。颜色目标是同屏导出预览，不要求另配印刷厂 ICC。

## 2. 首次安装 Python 依赖

Windows：双击 `setup_windows.bat`。脚本使用 `py -3.12` 创建包内 `.venv`，安装经测试的锁定版本并执行 `pip check`。若系统找不到 `py`，安装 Python 3.12 并启用 Python Launcher，或在包目录手动执行：

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python.exe -m pip install -r tools\requirements.lock.txt
.venv\Scripts\python.exe -m pip check
```

macOS：安装 Python 3.12 后，在终端执行 `bash setup_macos.command`。第一次安装需要连接 Python 包源；后续评分、审计、搜索不依赖网络或 API。macOS/Windows 启动脚本已检查内容，平台本机执行仍待验收；本次实际测试环境为 Linux / Python 3.12。

## 3. 开始自动运行

1. Windows 双击 `start_worker_windows.bat`；macOS 在终端运行 `bash start_worker_macos.command`。
2. 看到 `VisualMatch 1.4 worker READY` 后保持终端打开。worker 使用包内 `runtime/` 文件队列，不监听网络端口。不需要编辑 Python 路径或调用 shell 的 Illustrator 插件。
3. 在 Illustrator 激活已保存的 RGB 原稿，选择 **文件 → 脚本 → 其他脚本**，运行 `src/VM14_VisualMatch.jsx`。
4. 启动立即弹出状态提示。确认后自动执行：原稿文件审计和字体检查 → RGB 副本预览 → V1.3 普通转换 → 普通稿结构核对与重复导出 → 候选可见贡献探测 → 有限 CMYK 搜索 → 保存重开复核 → 最终发布门槛 → 输出。
5. 运行期间不要关闭 worker，不要手动编辑原稿/候选文件。可查看原稿旁新目录中的 `STATUS.txt`；如果目录无法创建，查看桌面 `VisualMatch_V14_LAST_STATUS.txt`。
6. 完成后打开输出目录的 `FINAL_REPORT.md`。只把其中经过确认的 `02_optimized_CMYK.ai` 作为本次结果；不要把 `trials/` 中被拒绝的试验文件交付。

## 4. 搜索规则和安全保护

- 首先只读审计 AI 原生私有数据与 PDF 兼容数据，并在 Illustrator 遍历 Layer、Group、CompoundPath、Path、TextFrame 及其他 pageItems。包含隐藏/锁定状态、边界、剪切组关系、透明度、混合模式、色源、渐变色标及几何参数。
- 标准 CMYK 路径填充/描边和标准渐变色标可参与搜索；渐变按实际共享定义归组。若同一渐变用于文字、隐藏/锁定对象，或者引用有歧义、色标不是 CMYK，则整个组跳过。文字颜色不参与优化。
- 几何边界仅用于粗筛。顶部 0–25%、底部 86–100% 候选交替入选，最多 8 组。先导出实际小幅改色探针，确认主视觉变化，再按变化区域原始色差总量排序。遮挡/剪切导致没有可见贡献的对象不继续搜索。
- 每次候选从**当前最佳 AI 文件重新复制**，仅改 CMYK 数值，保存、关闭、重开，核对结构并导出 PNG。被拒绝的试验副本不再进入后续链路；通过者才成为最佳快照。不会只用反向赋值假定回滚成功。
- 每次接受必须：整图相对当前最佳及普通稿均改善至少 **0.001 ΔE00**；顶部或底部至少一个相对普通稿改善 **0.001**；正文相对普通稿恶化不超过 **0.005**；`0.45×top+0.10×body+0.45×bottom` 下降；本次变化至少 4 个主视觉像素、至少 50% 变化像素在顶部/底部。门槛以未舍入数值计算，正文预算不会逐次累加。
- 最终还以普通稿为基准重算门槛；不满足就复制普通 AI/PNG 作为输出，标记 `fallback_baseline`。整体下降 3%、主视觉加权下降 5% 是期望目标，不作达标承诺。
- 原稿 SHA-256 前后验证；输入从不保存、改色或切换模式。输出使用带时间戳/随机后缀的新目录，拒绝覆盖已存在的 AI/PNG。原始压缩包不改写。
- 当前仅评分**一个选定画板**，所有画板和内容仍保留；其他画板不等于已视觉验收。共享颜色可能影响其他画板，见下面多画板限制。

## 5. 配置、停止与耗时

`config.json`：`maxExports` 默认 80（包括 RGB、普通重复图、候选及最终重开图）；`maxGroups` 默认 8；`step` 默认 3 个 CMYK 百分点；`fineStep` 默认 1；`timeoutSeconds` 默认 120；`artboardIndex=-1` 表示启动时的活动画板。画板索引从 0 开始。最多允许 8 组、500 次导出。

可在本次输出目录新建空白 `STOP.txt`。脚本在下一候选边界停止，完成最佳结果复核，结论标记 `PARTIAL`。正在进行的 Illustrator 保存/导出不能被安全强制中断。进度通过日志和 redraw 更新，但宿主导出时仍可能暂时繁忙。

若 worker 超时、结构不一致或保存失败，程序报告 `ERROR`，不发布未经完整验收的最终稿；保留 `best_verified.json` 指向的最佳快照与状态日志。修复后重新运行生成新目录，不会自动沿用残留试验。

## 6. 输出与结论含义

输出目录：`VisualMatch_V14_<时间戳>_<随机后缀>/`。

|文件|用途|
|---|---|
|`00_RGB_source.png`|RGB 文件只读副本导出的基准图|
|`01_ordinary_CMYK.ai/.png`|V1.3 路径完成的普通转换|
|`02_optimized_CMYK.ai/.png`|最终输出；无改善时与普通稿字节一致|
|`object_inventory.tsv`|普通 CMYK 稿完整公开 DOM 对象审计|
|`color_source_audit.tsv`|真实填充/描边/文字色源及渐变 stops|
|`unsupported_items.tsv`|不安全或不支持操作的明确原因|
|`source_*`、`source_file_evidence/`|RGB 源稿 DOM 与原生 AI/PDF 只读证据|
|`per_region_metrics.csv`、`preview_metrics.json`|三图的实际像素色差与变化面积|
|`optimization_trace.tsv/.json`、`color_matching_report.tsv`|每次候选对象、前后 CMYK、评分、接受/回滚理由|
|`structure_*_diff.json`|转换、候选保存重开、最终输出的完整结构差异|
|`best_verified.json`|最后已通过结构及像素评分的文件对|
|`run_manifest.json`、`run_results.json`|版本、导出条件、文件哈希、发布结论|
|`STATUS.txt`、`FINAL_REPORT.md`|过程日志与最终结论|
|`trials/`|试验副本、PNG、结构快照；包含失败候选，不能直接交付|

`PASS`：本次选定画板的测量门槛通过，公开 DOM 核对和源文件完整性通过；仍需人工检查 Illustrator 的可编辑性和不公开外观栈。

`NO_MEASURABLE_IMPROVEMENT`：无法证明改色有效，交付普通转换，不强行增加饱和度。

`PARTIAL`：用户停止后保留最佳已验证结果，搜索未完成。

`ERROR`：宿主、依赖、权限、字体、数据或安全检查失败；查看错误日志，不能当作验收成功。

## 7. 独立复算与开发测试

在包目录执行（Windows 把 Python 路径替换为 `.venv\Scripts\python.exe`）：

```bash
.venv/bin/python tools/compare_previews.py "/本次输出/00_RGB_source.png" "/本次输出/01_ordinary_CMYK.png" "/本次输出/02_optimized_CMYK.png" --out "/新的复核目录" --require-pass
```

`--require-pass` 在无改善时返回退出码 2；未加该参数时，只要统计成功就返回 0，不能把命令返回 0 当作视觉优化通过。尺寸不一致、非 PNG、无有效分区、色彩元数据不一致等属于错误，不重采样掩盖问题。带 ICC 的 PNG 经 LittleCMS 转 sRGB；无 ICC 的 PNG 统一按 sRGB 解释。RGB/RGBA 透明像素合成到白底。

复算随包 V1.3 三图时，应得到 `NO_MEASURABLE_IMPROVEMENT`。完整质量报告见根目录 `FINAL_REPORT.md`。

```bash
.venv/bin/python -m pip install -r tools/requirements-dev.txt
.venv/bin/python -m pytest -q tests
node tests/core_test.js
node tests/host_mock_test.js
npm install --no-save --package-lock=false acorn@8.15.0
node tests/static_check.js
```

## 8. 限制与排错

- **本次未运行 Illustrator 2025**：实际 JSX DOM、PNG 导出一致性、字体加载、AI 保存重开、中文可编辑性、真实优化效果，都需按 `docs/实机验收清单.md` 验收。
- 原生审计器针对本交接包的 PDF 兼容、带 Illustrator Zstandard 私有数据的 AI。缺少该结构的旧版/非 PDF 兼容 AI 会安全停止，不绕过审计。请在单独副本上由 Illustrator 保存兼容格式后再开始，保留原稿。
- 目前公开 DOM 无法完整读取任意实时外观、透明蒙版内部、插件/网格、符号定义和图案内部颜色。这些不展开、不栅格化、不替换；其内容可能限制可优化的面积。标准渐变 stop 的 opacity/ramp/midpoint 和渐变变换都保持不变。
- 多画板文档仅对选定画板评分。为了避免未评分画板受共享渐变影响，存在画板外颜色使用的共享渐变会保守跳过；单个跨画板对象也跳过。当前提供的原稿只有一个画板。
- 源文件中的“字体声明”与 Illustrator 已加载字体名称都检查；但人工仍须核对原稿打开时没有替换告警。程序不会下载或替换字体。
- `Worker not ready`：先启动同一份包的 worker。`Worker timeout`：查看终端与 `runtime/worker_errors.log`，确认无旧进程；必要时增加等待时间。
- `worker.lock exists`：先停止旧 worker；仅在确认进程已经退出后删除 `runtime/worker.lock`。不要同时启动两个 worker。
- `Object fingerprint mismatch`、`Structure changed`：保留 `structure_*_diff.json`，停止该次交付，不关闭检查来强行通过。
- `Baseline PNG pixels differ`：导出流程不稳定，微小 ΔE 改善不可信；保持相同颜色设置，确认外链素材不在变化，重新运行。
- 不支持相对微小像素改动换来整图恶化；不使用 RGB 整图覆盖 CMYK 来伪造保真。

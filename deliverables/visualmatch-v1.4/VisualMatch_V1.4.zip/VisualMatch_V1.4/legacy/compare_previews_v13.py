"""Quantify RGB-vs-CMYK preview fidelity. Usage:
python compare_previews.py RGB.png ordinary.png optimized.png --out OUTPUT_DIR
Requirements: pillow numpy scikit-image
Identical export pipelines assumed; untagged files are interpreted as sRGB.
"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from PIL import Image
from skimage.color import rgb2lab, deltaE_ciede2000


def read_rgb(path: Path) -> np.ndarray:
    with Image.open(path) as im:
        return np.asarray(im.convert('RGB'), dtype=np.float32) / 255.0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('rgb', type=Path)
    ap.add_argument('ordinary', type=Path)
    ap.add_argument('optimized', type=Path)
    ap.add_argument('--out', type=Path, default=Path('.'))
    args = ap.parse_args()
    imgs = [read_rgb(x) for x in (args.rgb, args.ordinary, args.optimized)]
    if not (imgs[0].shape == imgs[1].shape == imgs[2].shape):
        raise SystemExit('ERROR: PNG size mismatch; aborting rather than resizing and hiding errors')
    a,b,c = (rgb2lab(img) for img in imgs)
    db = deltaE_ciede2000(a,b)
    dc = deltaE_ciede2000(a,c)
    h,w = db.shape
    roi = {'all': (0.0,1.0),'top':(0.0,0.25),'body':(0.25,0.86),'bottom':(0.86,1.0)}
    rows=[]
    for name, (lo,hi) in roi.items():
        idx=slice(int(round(h*lo)),int(round(h*hi)))
        baseline=float(np.mean(db[idx]));optimized=float(np.mean(dc[idx]))
        rows.append({'region':name,'pixels':int(db[idx].size),
                     'ordinary_mean_DE00':round(baseline,4),
                     'optimized_mean_DE00':round(optimized,4),
                     'improvement_abs':round(baseline-optimized,4),
                     'improvement_pct':round((baseline-optimized)/baseline*100,3) if baseline else None})
    changed=(np.any(np.round(imgs[1]*255).astype('uint8') != np.round(imgs[2]*255).astype('uint8'),axis=2))
    info={'png_size':[w,h], 'changed_pixel_count':int(changed.sum()),
          'changed_pixel_percent':round(changed.mean()*100,4),
          'baseline_better_than_optimized':bool(rows[0]['optimized_mean_DE00'] >= rows[0]['ordinary_mean_DE00']),
          'metrics':rows,'notes':'CIEDE2000 on PNG previews interpreted consistently as sRGB; not printed-output color proof'}
    args.out.mkdir(parents=True, exist_ok=True)
    with (args.out/'per_region_metrics.csv').open('w',newline='',encoding='utf-8-sig') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)
    (args.out/'preview_metrics.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
    # The red channel marks where candidate is worse; green where candidate improves.
    improvement=np.clip(db-dc,-20,20)
    scale=np.clip(np.abs(improvement)/5.0,0,1)
    heat=np.zeros((h,w,3), dtype=np.uint8)
    heat[...,0] = np.where(improvement < -0.05,(scale*255),0).astype('uint8')
    heat[...,1] = np.where(improvement > 0.05,(scale*255),0).astype('uint8')
    heat[...,2] = 32
    Image.fromarray(heat).save(args.out/'difference_improvement_heatmap.png')
    for row in rows:
        print(row)
    print('Changed pixel percent:',info['changed_pixel_percent'])
    print('Wrote:', args.out.resolve())


if __name__=='__main__':
    main()

/* VisualMatch host-independent ES3 helpers. No eval, JSON dependency, or network. */
var VM14Core = (function () {
    function quote(s) {
        return '"' + String(s).replace(/[\\"\x00-\x1f\u2028\u2029]/g, function (c) {
            var n=c.charCodeAt(0).toString(16);
            if(c=='"'||c=='\\')return '\\'+c;
            return '\\u'+('0000'+n).slice(-4);
        }) + '"';
    }
    function stringify(v) {
        var a=[],k,i;
        if(v===null||typeof v=='undefined')return 'null';
        if(typeof v=='string')return quote(v);
        if(typeof v=='number') {if(!isFinite(v))throw Error('Non-finite JSON number');return String(v);}
        if(typeof v=='boolean')return v?'true':'false';
        if(v instanceof Array){for(i=0;i<v.length;i++)a.push(stringify(v[i]));return '['+a.join(',')+']';}
        for(k in v)if(Object.prototype.hasOwnProperty.call(v,k))a.push(quote(k)+':'+stringify(v[k]));
        return '{'+a.join(',')+'}';
    }
    function parse(text) {
        var s=String(text).replace(/^\uFEFF/,''),p=0;
        function ws(){while(/\s/.test(s.charAt(p)) && p<s.length)p++;}
        function str(){
            var out='',c,n; p++;
            while(p<s.length){c=s.charAt(p++);if(c=='"')return out;
                if(c=='\\') {c=s.charAt(p++);
                    if(c=='u'){n=s.substr(p,4);if(!/^[0-9a-fA-F]{4}$/.test(n))throw Error('JSON unicode');out+=String.fromCharCode(parseInt(n,16));p+=4;}
                    else if(c=='n')out+='\n';else if(c=='r')out+='\r';else if(c=='t')out+='\t';
                    else if(c=='b')out+='\b';else if(c=='f')out+='\f';
                    else if(c=='"'||c=='\\'||c=='/')out+=c;else throw Error('JSON escape');
                }else{if(c.charCodeAt(0)<32)throw Error('JSON control');out+=c;}
            }throw Error('JSON unterminated string');
        }
        function val(depth){
            if(depth>200)throw Error('JSON nesting');ws();var c=s.charAt(p),a,k,m;
            if(c=='"')return str();
            if(c=='['){p++;a=[];ws();if(s.charAt(p)==']'){p++;return a;}
                while(true){a.push(val(depth+1));ws();c=s.charAt(p++);if(c==']')return a;if(c!=',')throw Error('JSON array');}}
            if(c=='{'){p++;a={};ws();if(s.charAt(p)=='}'){p++;return a;}
                while(true){ws();if(s.charAt(p)!='"')throw Error('JSON key');k=str();
                    if(k=='__proto__'||k=='constructor'||k=='prototype')throw Error('Unsafe JSON key');
                    ws();if(s.charAt(p++)!=':')throw Error('JSON colon');a[k]=val(depth+1);ws();c=s.charAt(p++);if(c=='}')return a;if(c!=',')throw Error('JSON object');}}
            m=/^(true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/.exec(s.substr(p));
            if(!m)throw Error('JSON value at '+p);p+=m[0].length;
            if(m[0]=='true')return true;if(m[0]=='false')return false;if(m[0]=='null')return null;
            if(!isFinite(Number(m[0])))throw Error('Nonfinite JSON');return Number(m[0]);
        }
        var result=val(0);ws();if(p!=s.length)throw Error('Trailing JSON');return result;
    }
    function clamp(v){return Math.max(0,Math.min(100,v));}
    function shifted(colors,channel,delta,stop) {
        var a=[],i,j;
        for(i=0;i<colors.length;i++) {a[i]=colors[i].slice(0);if(stop<0||stop==i)a[i][channel]=clamp(a[i][channel]+delta);}
        return a;
    }
    function overlap(bounds,artboard,lo,hi){
        var top=artboard[1]-(artboard[1]-artboard[3])*lo;
        var bottom=artboard[1]-(artboard[1]-artboard[3])*hi;
        return Math.max(0,Math.min(bounds[2],artboard[2])-Math.max(bounds[0],artboard[0])) *
               Math.max(0,Math.min(bounds[1],top)-Math.max(bounds[3],bottom));
    }
    function same(a,b){return stringify(a)==stringify(b);}
    return {stringify:stringify,parse:parse,shifted:shifted,overlap:overlap,same:same};
})();
if(typeof module!='undefined' && module.exports)module.exports=VM14Core;

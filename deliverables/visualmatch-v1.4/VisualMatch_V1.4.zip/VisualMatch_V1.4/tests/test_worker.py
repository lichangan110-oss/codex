from pathlib import Path
import sys
import json
import subprocess
import time
import os
import signal
import numpy as np
import pytest
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from worker import Worker, structure_diff, atomic_json, load
from compare_previews import sha256


def test_full_structure_changes():
    a={'text':'凝英','styles':[{'font':'SourceHanSansCN-Bold','size':14}], 'bounds':[0.,1.]}
    b={'text':'凝荚','styles':[{'font':'Other','size':15}], 'bounds':[0.,1.02]}
    changes=structure_diff(a,b)
    assert len(changes)==4
    assert not structure_diff({'x':1.},{'x':1.0001})
    assert structure_diff({'locked':True},{'locked':False})


def setup_session(tmp):
    w=Worker();job=tmp/'job';job.mkdir()
    src=tmp/'original.ai';src.write_bytes(b'untouched source')
    for name,color in [('rgb.png',(90,80,220)),('base.png',(70,60,180))]:
        Image.new('RGB',(20,100),color).save(tmp/name)
    w.dispatch({'op':'init','job':str(job),'rgb':str(tmp/'rgb.png'),'baseline':str(tmp/'base.png'),
                'source':str(src),'source_hash':sha256(src)})
    arr=np.asarray(Image.open(tmp/'base.png')).copy();arr[:25]=(90,80,220);arr[86:]=(90,80,220)
    Image.fromarray(arr).save(tmp/'candidate.png');(tmp/'trial.ai').write_bytes(b'candidate editable mock')
    request={'op':'evaluate','job':str(job),'trial':1,'kind':'test','group':'gradient:x',
             'before':[[1,2,3,4]],'after':[[1,3,3,4]],'candidate_png':str(tmp/'candidate.png'),
             'candidate_ai':str(tmp/'trial.ai'),'structure_ok':True}
    return w,job,src,request


def test_transaction_commit(tmp_path):
    w,job,src,r=setup_session(tmp_path);before=sha256(src)
    assert w.dispatch(r)['accepted']
    s=w.sessions[str(job.resolve())]
    assert s['best_png'].endswith('base.png') # evaluate alone never advances best
    w.dispatch({'op':'commit','job':str(job),'trial':1,'ai':r['candidate_ai'],'png':r['candidate_png']})
    assert s['best_png']==r['candidate_png'] and sha256(src)==before
    assert load(job/'best_verified.json')['trial']==1


def test_structural_rejection_never_commit(tmp_path):
    w,job,src,r=setup_session(tmp_path);r['structure_ok']=False
    assert not w.dispatch(r)['accepted']
    with pytest.raises(ValueError,match='rejected'):
        w.dispatch({'op':'commit','job':str(job),'trial':1,'ai':r['candidate_ai'],'png':r['candidate_png']})
    assert w.sessions[str(job.resolve())]['best_png'].endswith('base.png')


def test_recheck_original_hash(tmp_path):
    w,job,src,r=setup_session(tmp_path);w.dispatch(r);src.write_bytes(b'external change')
    with pytest.raises(ValueError,match='Source hash'):
        w.dispatch({'op':'commit','job':str(job),'trial':1,'ai':r['candidate_ai'],'png':r['candidate_png']})


def test_tampered_candidate_rejected(tmp_path):
    w,job,src,r=setup_session(tmp_path);w.dispatch(r);Path(r['candidate_ai']).write_bytes(b'tampered')
    with pytest.raises(ValueError,match='files changed'):
        w.dispatch({'op':'commit','job':str(job),'trial':1,'ai':r['candidate_ai'],'png':r['candidate_png']})


def test_ipc_subprocess(tmp_path):
    script=Path(__file__).resolve().parents[1]/'tools/worker.py'
    p=subprocess.Popen([sys.executable,str(script),'--bridge',str(tmp_path)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
        until=time.monotonic()+15
        while not (tmp_path/'requests').exists() and time.monotonic()<until: time.sleep(.05)
        atomic_json(tmp_path/'requests/ping_test.json',{'id':'ping_test','op':'ping'})
        reply=tmp_path/'responses/ping_test.json'
        while not reply.exists() and time.monotonic()<until: time.sleep(.05)
        assert load(reply)['version']=='1.4.0'
        atomic_json(tmp_path/'requests/mismatch.json',{'id':'wrong','op':'ping'})
        reply=tmp_path/'responses/mismatch.json'
        while not reply.exists() and time.monotonic()<until: time.sleep(.05)
        assert not load(reply)['ok']
    finally:
        p.send_signal(signal.SIGINT);p.communicate(timeout=10)
    assert p.returncode==0
    assert not (tmp_path/'worker.lock').exists()


def test_publication_gate_uses_baseline(tmp_path):
    w,job,src,r=setup_session(tmp_path)
    assert w.dispatch({'op':'publication_gate','job':str(job),'path':r['candidate_png']})['accepted']
    assert not w.dispatch({'op':'publication_gate','job':str(job),'path':str(tmp_path/'base.png')})['accepted']


def test_final_report_and_baseline_pair(tmp_path):
    import shutil
    w,job,src,r=setup_session(tmp_path)
    shutil.copy(tmp_path/'rgb.png',job/'00_RGB_source.png')
    shutil.copy(tmp_path/'base.png',job/'01_ordinary_CMYK.png')
    shutil.copy(tmp_path/'base.png',job/'02_optimized_CMYK.png')
    (job/'01_ordinary_CMYK.ai').write_bytes(b'mock ordinary AI')
    shutil.copy(job/'01_ordinary_CMYK.ai',job/'02_optimized_CMYK.ai')
    atomic_json(job/'run_manifest.json',{'version':'test'})
    atomic_json(job/'structure_final_diff.json',{'equal':True,'differences':[]})
    result=w.dispatch({'op':'finalize','job':str(job),'fallback':True,
                      'structure_report':str(job/'structure_final_diff.json')})
    assert result=={'status':'NO_MEASURABLE_IMPROVEMENT','safe':True}
    report=load(job/'run_results.json')
    assert report['source_unchanged'] and report['verified_file_pair']
    assert report['changed_pixels']==0 and report['fallback_baseline']
    assert (job/'FINAL_REPORT.md').exists() and (job/'per_region_metrics.csv').exists()

"""V1.4 pixel oracle; retains V1.3 three-preview CLI and adds strict acceptance gates."""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import numpy as np
from PIL import Image, ImageCms
from skimage.color import rgb2lab, deltaE_ciede2000

REGIONS = {'all': (0., 1.), 'top': (0., .25), 'body': (.25, .86), 'bottom': (.86, 1.)}
DEFAULT_POLICY = {'min_global_improvement': .001, 'min_hero_improvement': .001,
                  'max_body_regression': .005, 'min_changed_hero_pixels': 4,
                  'min_hero_changed_fraction': .5}


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_rgb(path):
    """Explicit sRGB comparison, ICC converted when present; transparent pixels on white."""
    with Image.open(path) as im:
        if im.format != 'PNG' or im.mode not in ('RGB', 'RGBA'):
            raise ValueError('Expected Illustrator RGB/RGBA PNG: ' + str(path))
        icc = im.info.get('icc_profile')
        meta = {'size': list(im.size), 'mode': im.mode, 'icc_sha256':
                hashlib.sha256(icc).hexdigest() if icc else None,
                'interpretation': 'ICC converted to sRGB' if icc else 'untagged assumed sRGB',
                'gamma': im.info.get('gamma'), 'sha256': sha256(path)}
        alpha = im.getchannel('A') if im.mode == 'RGBA' else None
        rgb = im.convert('RGB')
        if icc:
            rgb = ImageCms.profileToProfile(rgb, ImageCms.ImageCmsProfile(io.BytesIO(icc)),
                                           ImageCms.createProfile('sRGB'), outputMode='RGB')
        if alpha is not None:
            bg = Image.new('RGB', rgb.size, 'white')
            bg.paste(rgb, mask=alpha)
            rgb = bg
        return np.asarray(rgb, dtype=np.uint8), meta


def slices(height):
    cuts = {k: slice(int(round(height*a)), int(round(height*b))) for k,(a,b) in REGIONS.items()}
    if any(v.start == v.stop for v in cuts.values()):
        raise ValueError('Image too short for nonempty comparison regions')
    return cuts


def weighted(metrics):
    return .45*metrics['top'] + .1*metrics['body'] + .45*metrics['bottom']


def metrics_of(error):
    return {k: float(error[s].mean()) for k,s in slices(error.shape[0]).items()}


def validate_policy(policy=None):
    p = dict(DEFAULT_POLICY)
    if policy:
        if set(policy)-set(p):
            raise ValueError('Unknown acceptance policy field')
        p.update(policy)
    if any(not np.isfinite(v) or v < 0 for v in p.values()):
        raise ValueError('Policy values must be finite and nonnegative')
    if p['min_global_improvement'] <= 0 or p['min_hero_improvement'] <= 0:
        raise ValueError('Improvement thresholds must be strictly positive')
    if not 0 <= p['min_hero_changed_fraction'] <= 1:
        raise ValueError('Invalid hero fraction')
    return p


def acceptance(baseline, incumbent, candidate, impact, policy=None):
    p = validate_policy(policy)
    values = list(baseline.values()) + list(incumbent.values()) + list(candidate.values())
    if not all(np.isfinite(v) for v in values):
        return False, ['nonfinite_metrics']
    reasons = []
    if incumbent['all'] - candidate['all'] < p['min_global_improvement']:
        reasons.append('no_global_improvement_over_best')
    if baseline['all'] - candidate['all'] < p['min_global_improvement']:
        reasons.append('no_global_improvement_over_baseline')
    if max(baseline['top']-candidate['top'], baseline['bottom']-candidate['bottom']) < p['min_hero_improvement']:
        reasons.append('no_hero_improvement')
    if candidate['body'] > baseline['body'] + p['max_body_regression']:
        reasons.append('body_regression')
    if weighted(candidate) >= weighted(incumbent):
        reasons.append('no_weighted_improvement')
    if impact['hero_changed_pixels'] < p['min_changed_hero_pixels']:
        reasons.append('no_visible_hero_contribution')
    if impact['hero_changed_fraction'] < p['min_hero_changed_fraction']:
        reasons.append('change_concentrated_outside_hero')
    return not reasons, reasons


class Oracle:
    def __init__(self, rgb, ordinary):
        self.rgb, self.rgb_meta = read_rgb(rgb)
        self.base, self.base_meta = read_rgb(ordinary)
        self._check(self.base, self.base_meta)
        self.target_lab = rgb2lab(self.rgb.astype(np.float64)/255.)
        self.base_error = self.error(self.base)
        self.baseline = metrics_of(self.base_error)

    def _check(self, image, meta):
        if self.rgb.shape != image.shape:
            raise ValueError('PNG size mismatch; never resize to hide an export error')
        # Different declared gammas with no ICC would invalidate the shared sRGB assumption.
        if not self.rgb_meta['icc_sha256'] and not meta['icc_sha256']:
            if self.rgb_meta['gamma'] != meta['gamma']:
                raise ValueError('Inconsistent untagged PNG gamma metadata')
        slices(image.shape[0])

    def error(self, rgb):
        return deltaE_ciede2000(self.target_lab, rgb2lab(rgb.astype(np.float64)/255.))

    def measure(self, path, previous=None):
        image, meta = read_rgb(path)
        self._check(image, meta)
        err = self.error(image)
        prev = self.base if previous is None else read_rgb(previous)[0]
        if prev.shape != image.shape:
            raise ValueError('Previous PNG size mismatch')
        mask = np.any(image != prev, axis=2)
        regions = slices(image.shape[0])
        changes = {k: int(mask[s].sum()) for k,s in regions.items()}
        hero = changes['top'] + changes['bottom']
        impact = {'changed_pixels': changes['all'], 'changed_by_region': changes,
                  'hero_changed_pixels': hero, 'hero_changed_fraction': hero/max(1, changes['all']),
                  'changed_pixel_percent': float(mask.mean()*100),
                  'hero_error_mass': float(sum(self.base_error[regions[k]][mask[regions[k]]].sum()
                                              for k in ('top', 'bottom')))}
        return metrics_of(err), impact, meta, err


def compare(rgb, ordinary, optimized, out, policy=None):
    oracle = Oracle(rgb, ordinary)
    metrics, impact, meta, err = oracle.measure(optimized)
    accepted, reasons = acceptance(oracle.baseline, oracle.baseline, metrics, impact, policy)
    rows=[]
    for name, s in slices(err.shape[0]).items():
        b, c = oracle.baseline[name], metrics[name]
        rows.append({'region': name, 'pixels': int(err[s].size), 'ordinary_mean_DE00': b,
                     'optimized_mean_DE00': c, 'improvement_abs': b-c,
                     'improvement_pct': (b-c)/b*100 if b else None})
    result = {'schema': 'VisualMatch-1.4', 'status': 'PASS' if accepted else 'NO_MEASURABLE_IMPROVEMENT',
              'rejection_reasons': reasons, 'png_size': [err.shape[1],err.shape[0]],
              'metrics': rows, 'baseline': oracle.baseline, 'candidate': metrics, **impact,
              'weighted_before': weighted(oracle.baseline), 'weighted_after': weighted(metrics),
              'policy': validate_policy(policy), 'inputs': [oracle.rgb_meta,oracle.base_meta,meta],
              'notes': 'Same-export screen preview comparison in sRGB; not print proof. No Illustrator claim.'}
    out=Path(out); out.mkdir(parents=True, exist_ok=True)
    with (out/'per_region_metrics.csv').open('w', newline='', encoding='utf-8-sig') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (out/'preview_metrics.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    improvement=np.clip(oracle.base_error-err,-20,20)
    scale=np.clip(np.abs(improvement)/5.,0,1)
    heat=np.zeros((*err.shape,3),dtype=np.uint8)
    heat[...,0]=np.where(improvement < -.05,scale*255,0).astype('uint8')
    heat[...,1]=np.where(improvement > .05,scale*255,0).astype('uint8')
    heat[...,2]=32
    Image.fromarray(heat).save(out/'difference_improvement_heatmap.png')
    return result


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('rgb',type=Path);ap.add_argument('ordinary',type=Path);ap.add_argument('optimized',type=Path)
    ap.add_argument('--out',type=Path,default=Path('.'))
    ap.add_argument('--require-pass',action='store_true',help='Exit 2 when candidate fails publication gates')
    args=ap.parse_args()
    r=compare(args.rgb,args.ordinary,args.optimized,args.out)
    print(json.dumps({k:r[k] for k in ('status','baseline','candidate','changed_pixels','rejection_reasons')},indent=2))
    if args.require_pass and r['status']!='PASS': raise SystemExit(2)

if __name__=='__main__': main()

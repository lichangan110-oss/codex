"""Run portable development checks and retain exit codes/output. Requires Node + acorn for ES3."""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

root=Path(__file__).resolve().parent.parent
ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=root/'development_evidence')
args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
commands=[
 ('pytest',[sys.executable,'-m','pytest','-q','tests','--junitxml='+str(args.out/'pytest.xml')]),
 ('core',['node','tests/core_test.js']),
 ('host_mock',['node','tests/host_mock_test.js']),
 ('es3',['node','tests/static_check.js']),
 ('python_compile',[sys.executable,'-m','compileall','-q','tools','tests']),
]
results=[]
for name,cmd in commands:
    p=subprocess.run(cmd,cwd=root,text=True,encoding='utf-8',errors='replace',stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (args.out/(name+'.log')).write_text(p.stdout,encoding='utf-8')
    results.append({'check':name,'command':cmd,'exit_code':p.returncode})
    print(name+': '+str(p.returncode)+'\n'+p.stdout,flush=True)
(args.out/'check_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
raise SystemExit(1 if any(r['exit_code'] for r in results) else 0)

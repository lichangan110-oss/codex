#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
python3.12 -m venv .venv
.venv/bin/python -m pip install -r tools/requirements.lock.txt
.venv/bin/python -m pip check
printf '%s\n' 'Setup complete. Run start_worker_macos.command, then the JSX in Illustrator.'

const assert=require('node:assert/strict');
const C=require('../src/vm14_core.js');
let n=0;function test(name,fn){fn();n++;console.log('PASS '+name);}
test('JSON roundtrip unicode/escapes',()=>{const v={text:'凝英\n中文\u2028',a:[true,null,-1.2e4,'\\"']};assert.deepEqual(C.parse(C.stringify(v)),v);});
test('JSON refuses code and unsafe keys',()=>{for(const v of ['(function(){})()','{"__proto__":1}','[1,]','1e999'])assert.throws(()=>C.parse(v));});
test('JSON rejects nonfinite numbers',()=>assert.throws(()=>C.stringify(NaN)));
test('gradient edits preserve originals and unselected stops',()=>{let a=[[99,2,3,4],[20,30,40,50]];let b=C.shifted(a,0,3,0);assert.deepEqual(b,[[100,2,3,4],[20,30,40,50]]);assert.equal(a[0][0],99);});
test('gradient all-stop channel offsets clamp',()=>assert.deepEqual(C.shifted([[0,2,3,4],[20,30,40,50]],0,-3,-1),[[0,2,3,4],[17,30,40,50]]));
test('top and bottom coordinates use artboard origin',()=>{let art=[100,1000,200,0];assert.equal(C.overlap([100,1000,200,750],art,0,.25),25000);assert.equal(C.overlap([100,140,200,0],art,.86,1),14000);assert.equal(C.overlap([0,300,50,200],art,0,1),0);});
console.log(n+' core tests passed (Node, not Illustrator).');

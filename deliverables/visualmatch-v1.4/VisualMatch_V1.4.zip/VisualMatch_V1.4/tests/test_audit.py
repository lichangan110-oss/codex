from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from audit_ai import audit


def test_supplied_actual_ai_native_gradients(tmp_path):
    source=next((Path(__file__).resolve().parents[1]/'reference').glob('*.ai'))
    r=audit(source,tmp_path)
    assert r['sha256_before']==r['sha256_after']=='741e1f1f0eaa7cf502c6b59f1f16c5669b5d8eb877de449c2bde4aa671259109'
    by_id={o['xmluid']:o for o in r['main_visual_objects']}
    assert by_id['hero_base']['gradient']=='未命名的渐变'
    assert by_id['footer_wave_main']['gradient']=='未命名的渐变 17'
    assert by_id['v4_C_footer_color_band']['gradient']=='未命名的渐变 89'
    assert set(r['page_shading_types'])=={2,3}
    assert 'SourceHanSansCN-Bold' in r['fonts']

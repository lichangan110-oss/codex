#target illustrator
// VisualMatch V1.3 - RGB-to-CMYK auto matching pilot.
// ES3 / ExtendScript; tested with static JS syntax checking, not Illustrator runtime.
// Safety: NEVER save, recolor, or switch mode of the source document.
alert('VM13 START\n\nVisualMatch V1.3 script is running.\nThe original RGB document will not be changed.');

(function () {
    var source = null, sourceFile = null, jobFolder = null;
    var working = null, ordinaryFile = null, optimizedFile = null;
    var desktopLog = new File(Folder.desktop.fsName + '/VisualMatch_LAST_STATUS.txt');
    var logLines = [], stage = 'BOOT';
    var MAX_SEARCH_COLORS = 55;
    var colors = [], groups = {}, groupList = [], sourceText = '', sourceCounts = '';
    var stats = {rgbSamples:0, cmykSamples:0, searchDone:0, improved:0, applied:0, skipped:0, errors:0};

    function writeFile(f, s) {
        f.encoding = 'UTF-8';
        if (!f.open('w')) throw new Error('Cannot write ' + f.fsName);
        f.write('\uFEFF' + s); f.close();
    }
    function log(msg) {
        var row = (new Date()).toString() + ' | ' + stage + ' | ' + msg;
        logLines.push(row);
        try { writeFile(desktopLog, logLines.join('\r\n')); } catch (ignore) {}
        if (jobFolder) {
            try { writeFile(new File(jobFolder.fsName + '/STATUS.txt'), logLines.join('\r\n')); } catch (ignore2) {}
        }
    }
    function step(name) { stage = name; log('BEGIN'); }
    function errtext(e) {return String(e) + (e && e.line ? ' (line ' + e.line + ')' : '');}
    function mode(doc) {
        if (doc.documentColorSpace == DocumentColorSpace.RGB) return 'RGB';
        if (doc.documentColorSpace == DocumentColorSpace.CMYK) return 'CMYK';
        return 'UNKNOWN';
    }
    function pad(n) {return n < 10 ? '0' + n : String(n);}
    function stamp() {
        var d=new Date();
        return ''+d.getFullYear()+pad(d.getMonth()+1)+pad(d.getDate())+'_'+pad(d.getHours())+pad(d.getMinutes())+pad(d.getSeconds());
    }
    function counts(d) {return d.pathItems.length + '/' + d.textFrames.length + '/' + d.gradients.length;}
    function textDigest(d) {
        var a=[],i;
        for(i=0;i<d.textFrames.length;i++) {
            try {a.push(d.textFrames[i].contents);}catch(e){a.push('<TEXT_UNREADABLE>');}
        }
        return a.join('\u0001');
    }
    function clamp(x) {return Math.max(0,Math.min(100,x));}
    function rounded(x) {return Math.round(x*100)/100;}
    function keyRGB(a) {return Math.round(a[0]*10)+'_'+Math.round(a[1]*10)+'_'+Math.round(a[2]*10);}
    function keyInk(a) {return Math.round(a[0]*10)+'_'+Math.round(a[1]*10)+'_'+Math.round(a[2]*10)+'_'+Math.round(a[3]*10);}
    function rgb(c) {
        try {if(c && c.typename=='RGBColor')return [c.red,c.green,c.blue];}
        catch(e){}return null;
    }
    function ink(c) {
        try {if(c && c.typename=='CMYKColor')return [c.cyan,c.magenta,c.yellow,c.black];}
        catch(e){}return null;
    }
    function newInk(c) {
        var n=new CMYKColor(); n.cyan=c[0];n.magenta=c[1];n.yellow=c[2];n.black=c[3];return n;
    }
    function labFromRGB(c) {
        return app.convertSampleColor(ImageColorSpace.RGB,c,ImageColorSpace.LAB,ColorConvertPurpose.previewpurpose);
    }
    function labFromCMYK(c) {
        return app.convertSampleColor(ImageColorSpace.CMYK,c,ImageColorSpace.LAB,ColorConvertPurpose.previewpurpose);
    }
    function diff(a,b) {
        var d0=a[0]-b[0],d1=a[1]-b[1],d2=a[2]-b[2];
        return Math.sqrt(d0*d0+d1*d1+d2*d2);
    }
    function mutable(obj) {
        try {
            if(obj.locked || obj.hidden) return false;
            var p=obj.parent;
            while(p) {
                if(p.typename=='Layer' && (!p.visible || p.locked)) return false;
                if(p.typename=='GroupItem' && (p.locked || p.hidden)) return false;
                if(p.typename=='Document') break;
                p=p.parent;
            }
            return true;
        } catch(e) {return false;}
    }
    function collectRGB(d) {
        var a=[],i,j,frame,chars,c,col;
        for(i=0;i<d.pathItems.length;i++) {
            try {
                var p=d.pathItems[i];
                if(!mutable(p)) continue;
                if(p.filled && (c=rgb(p.fillColor)))a.push({t:'p',i:i,j:0,part:'f',rgb:c});
                if(p.stroked && (c=rgb(p.strokeColor)))a.push({t:'p',i:i,j:0,part:'s',rgb:c});
            } catch(e) {stats.skipped++;}
        }
        for(i=0;i<d.textFrames.length;i++) {
            try {
                frame=d.textFrames[i];if(!mutable(frame)) continue;
                chars=frame.textRange.characters;
                if(chars.length>10000) {stats.skipped++;continue;}
                for(j=0;j<chars.length;j++) {
                    try {
                        col=chars[j].characterAttributes.fillColor;
                        if(c=rgb(col))a.push({t:'t',i:i,j:j,part:'f',rgb:c});
                    } catch(e2) {stats.skipped++;}
                }
            } catch(e3) {stats.skipped++;}
        }
        stats.rgbSamples=a.length;
        log('RGB colored properties captured: '+a.length+'. Native gradients: '+d.gradients.length);
        return a;
    }
    function getColor(d,s) {
        if(s.t=='p') {
            var p=d.pathItems[s.i]; return s.part=='f' ? p.fillColor : p.strokeColor;
        }
        return d.textFrames[s.i].textRange.characters[s.j].characterAttributes.fillColor;
    }
    function setColor(d,s,c) {
        var target=newInk(c);
        if(s.t=='p') {
            var p=d.pathItems[s.i];
            if(!mutable(p))return false;
            if(s.part=='f')p.fillColor=target;else p.strokeColor=target;
        } else {
            var t=d.textFrames[s.i];
            if(!mutable(t))return false;
            t.textRange.characters[s.j].characterAttributes.fillColor=target;
        }
        return true;
    }
    function exportPNG(d, basename) {
        try {
            var o=new ExportOptionsPNG24();
            o.antiAliasing=true;o.artBoardClipping=true;o.transparency=false;
            o.horizontalScale=100;o.verticalScale=100;
            d.exportFile(new File(jobFolder.fsName+'/'+basename),ExportType.PNG24,o);
            log('PNG saved: '+basename+'.png');
        } catch(e) {stats.errors++;log('WARNING PNG export failed: '+errtext(e));}
    }
    function duplicateAndOpen(file, output) {
        if(output.exists) throw new Error('Refusing to overwrite: '+output.fsName);
        if(!file.copy(output.fsName)) throw new Error('File copy failed: '+file.fsName);
        var d=app.open(output);
        app.activeDocument=d;
        if(d.fullName.fsName == sourceFile.fsName)throw new Error('Safety check: source unexpectedly became active');
        return d;
    }
    function baselineFromOrdinary(d,a) {
        var i,s,c,k,g;
        for(i=0;i<a.length;i++) {
            s=a[i];
            try {
                c=ink(getColor(d,s));
                if(!c) {stats.skipped++;continue;}
                stats.cmykSamples++;
                k=keyRGB(s.rgb)+'_x_'+keyInk(c);
                if(!groups[k]) {
                    g={key:k,rgb:s.rgb,base:c,uses:0,matched:false,best:c,before:0,after:0};
                    groups[k]=g; groupList.push(g);
                }
                groups[k].uses++;
                s.key=k;
            }catch(e){stats.skipped++;}
        }
        groupList.sort(function(a,b){return b.uses-a.uses;});
        log('CMYK properties: '+stats.cmykSamples+'; distinct RGB/baseline groups: '+groupList.length);
    }
    function scoreCandidate(c,targetLab) {return diff(labFromCMYK(c),targetLab);}
    function optimize(g) {
        var lab=labFromRGB(g.rgb), best=g.base.slice(0);
        var before=scoreCandidate(best,lab), bestScore=before;
        var steps=[10,3],s,ch,dir,candidate,v;
        for(s=0;s<steps.length;s++) {
            for(ch=0;ch<4;ch++) {
                for(dir=-1;dir<=1;dir+=2) {
                    candidate=best.slice(0);
                    candidate[ch]=rounded(clamp(candidate[ch]+dir*steps[s]));
                    if(candidate[ch]==best[ch])continue;
                    v=scoreCandidate(candidate,lab);
                    if(v+0.01<bestScore) {bestScore=v;best=candidate;}
                }
            }
        }
        g.before=before;g.after=bestScore;
        g.matched=true;
        if(before-bestScore>=0.35) {g.best=best;stats.improved++;}
        else {g.best=g.base;g.after=before;}
    }
    function tsvRow(a){return a.join('\t');}
    function table() {
        var lines=[tsvRow(['RGB target','CMYK ordinary','CMYK optimized','approx DeltaE76 before','approx DeltaE76 after','Uses','Searched'])];
        var i,g;
        for(i=0;i<groupList.length;i++) {
            g=groupList[i];
            lines.push(tsvRow([g.rgb.join(','),g.base.join(','),g.best.join(','),rounded(g.before),rounded(g.after),g.uses,g.matched?'YES':'NO']));
        }
        writeFile(new File(jobFolder.fsName+'/color_matching_report.tsv'),lines.join('\r\n'));
    }
    function safeClose(d, save) {
        if(d) { try {d.close(save ? SaveOptions.SAVECHANGES : SaveOptions.DONOTSAVECHANGES);}catch(e){log('CLOSE WARNING '+errtext(e));} }
    }
    log('SCRIPT ENTERED. Illustrator version: '+app.version);
    try {
        step('01 VALIDATION');
        if(app.documents.length<1)throw new Error('No open document');
        source=app.activeDocument;
        if(mode(source)!='RGB')throw new Error('Active document is not RGB: '+source.name+' is '+mode(source));
        if(!source.saved)throw new Error('Source has unsaved changes. Save manually then rerun.');
        sourceFile=source.fullName;
        if(!/\.ai$/i.test(sourceFile.name))throw new Error('Open a saved .ai file, not '+sourceFile.name);
        log('Source: '+sourceFile.fsName+' | Mode RGB | Saved YES');
        if(!confirm('VM13 READY\n\nRGB file: '+source.name+'\n\nWill make NEW CMYK files in an output folder next to this file.\nThe RGB source will NOT be saved or modified.\n\nRun automated A/B comparison?')){
            log('USER CANCELLED');return;
        }
        jobFolder=new Folder(sourceFile.parent.fsName+'/VisualMatch_VM13_'+stamp());
        if(!jobFolder.create())throw new Error('Cannot create output folder: '+jobFolder.fsName);
        ordinaryFile=new File(jobFolder.fsName+'/01_ordinary_CMYK.ai');
        optimizedFile=new File(jobFolder.fsName+'/02_optimized_CMYK.ai');
        sourceCounts=counts(source);sourceText=textDigest(source);
        step('02 CAPTURE RGB');
        colors=collectRGB(source);
        exportPNG(source,'00_RGB_source');
        step('03 ORDINARY CONVERSION');
        working=duplicateAndOpen(sourceFile,ordinaryFile);
        if(mode(working)!='RGB')throw new Error('Copied file is not RGB; stopped safely');
        app.redraw();
        app.executeMenuCommand('doc-color-cmyk');
        app.redraw();
        log('Working copy current mode: '+mode(working));
        if(mode(working)!='CMYK') throw new Error('CMYK mode switch did not succeed');
        if(counts(working)!=sourceCounts || textDigest(working)!=sourceText)
            throw new Error('Document structure/text changed on conversion: stopped; source untouched');
        baselineFromOrdinary(working,colors);
        working.save();
        exportPNG(working,'01_ordinary_CMYK');
        safeClose(working,false);working=null;
        step('04 OPTIMIZATION COPY');
        working=duplicateAndOpen(ordinaryFile,optimizedFile);
        if(mode(working)!='CMYK')throw new Error('Optimization copy is not CMYK');
        step('05 OPTIMIZATION SEARCH');
        for(var i=0;i<groupList.length && i<MAX_SEARCH_COLORS;i++) {
            try {optimize(groupList[i]);stats.searchDone++;}
            catch(e){stats.errors++;log('Optimization group '+i+' error: '+errtext(e));}
            if(i%5==0 || i==MAX_SEARCH_COLORS-1)log('Search '+(i+1)+'/'+Math.min(groupList.length,MAX_SEARCH_COLORS)+' complete. Improved groups '+stats.improved);
        }
        step('06 APPLY COLORS');
        for(i=0;i<colors.length;i++) {
            var s=colors[i],g=s.key ? groups[s.key] : null;
            if(!g || !g.matched)continue;
            if(g.best.join(',')==g.base.join(','))continue;
            try {if(setColor(working,s,g.best)) stats.applied++;}
            catch(e2){stats.errors++;log('Apply item '+i+' failed: '+errtext(e2));}
        }
        log('Applied color edits: '+stats.applied);
        if(counts(working)!=sourceCounts || textDigest(working)!=sourceText)
            throw new Error('Structure/text check failed after recolor; optimized copy not saved');
        working.save();
        exportPNG(working,'02_optimized_CMYK');
        safeClose(working,false);working=null;
        step('07 FINISH');
        table();
        var summary=[];
        summary.push('VisualMatch V1.3 pilot report');
        summary.push('RGB file: '+sourceFile.fsName);
        summary.push('Documents: paths/text/gradients '+sourceCounts);
        summary.push('Source color properties found: '+stats.rgbSamples);
        summary.push('Mapped to actual CMYK colors: '+stats.cmykSamples);
        summary.push('Candidate groups: '+groupList.length);
        summary.push('Groups searched (first '+MAX_SEARCH_COLORS+' by frequency): '+stats.searchDone);
        summary.push('Groups with improved simulated Lab distance: '+stats.improved);
        summary.push('Color edits applied: '+stats.applied);
        summary.push('Skipped operations: '+stats.skipped+'; Errors: '+stats.errors);
        summary.push('All results in: '+jobFolder.fsName);
        summary.push('LIMITS: no raster/linked images, effects/meshes, spot colors or arbitrary appearance-stack colors optimized. Native gradients require separate handling.');
        summary.push('DeltaE76 = ICC approximation from Illustrator convertSampleColor, NOT measured monitor pixels.');
        summary.push('Same-screen actual PNG comparison is required. Source .ai was never modified.');
        writeFile(new File(jobFolder.fsName+'/REPORT.txt'),summary.join('\r\n'));
        app.activeDocument=source;
        log('DONE. No source changes.');
        alert('VM13 COMPLETE\n\n'+summary.slice(3,9).join('\n')+'\n\nOutputs:\n'+jobFolder.fsName+'\n\nPlease compare the 3 PNG files.');
    } catch(fatal) {
        log('ERROR: '+errtext(fatal));
        safeClose(working,false);working=null;
        try {if(source)app.activeDocument=source;}catch(ex){}
        alert('VM13 STOPPED at '+stage+'\n\n'+errtext(fatal)+'\n\nDesktop log: VisualMatch_LAST_STATUS.txt\nOriginal RGB source was not modified.');
    }
})();

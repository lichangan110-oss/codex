from pathlib import Path
import sys
import numpy as np
import pytest
from PIL import Image, ImageCms, PngImagePlugin
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from compare_previews import Oracle, acceptance, compare, DEFAULT_POLICY, read_rgb, validate_policy

ROOT=Path(__file__).resolve().parents[1]
REF=ROOT/'reference'


def png(tmp,name,rgb,size=(20,100),mode='RGB'):
    p=tmp/name;Image.new(mode,size,rgb).save(p);return p


def test_real_v13_rejected(tmp_path):
    r=compare(REF/'00_RGB_source.png',REF/'01_ordinary_CMYK.png',REF/'02_optimized_CMYK.png',tmp_path)
    assert r['status']=='NO_MEASURABLE_IMPROVEMENT'
    assert r['baseline']['all']==pytest.approx(3.3687164,abs=1e-5)
    assert r['candidate']['all']==pytest.approx(3.3774200,abs=1e-5)
    assert r['changed_pixels']==14804
    assert r['changed_by_region']['bottom']==0
    assert 'body_regression' in r['rejection_reasons']


def test_baseline_not_optimization(tmp_path):
    r=compare(REF/'00_RGB_source.png',REF/'01_ordinary_CMYK.png',REF/'01_ordinary_CMYK.png',tmp_path)
    assert r['status']=='NO_MEASURABLE_IMPROVEMENT'
    assert r['changed_pixels']==0


def test_actual_image_improvement(tmp_path):
    a=png(tmp_path,'rgb.png',(90,80,220))
    b=png(tmp_path,'base.png',(70,60,180))
    arr=np.asarray(Image.open(b)).copy()
    arr[:25]=(90,80,220);arr[86:]=(90,80,220)
    c=tmp_path/'candidate.png';Image.fromarray(arr).save(c)
    r=compare(a,b,c,tmp_path/'out')
    assert r['status']=='PASS'
    assert r['candidate']['body']==r['baseline']['body']
    assert r['hero_changed_fraction']==1


def test_size_mismatch(tmp_path):
    with pytest.raises(ValueError,match='size mismatch'):
        Oracle(png(tmp_path,'a.png','white'),png(tmp_path,'b.png','white',(21,100)))


def test_transparent_pixels_use_white(tmp_path):
    a=png(tmp_path,'a.png',(255,0,0,0),mode='RGBA')
    arr,_=read_rgb(a);assert (arr==255).all()


def test_reject_non_png(tmp_path):
    a=tmp_path/'rgb.jpg';Image.new('RGB',(20,100)).save(a)
    with pytest.raises(ValueError,match='Expected'): read_rgb(a)


def test_tiny_image_rejected(tmp_path):
    with pytest.raises(ValueError,match='too short'):
        Oracle(png(tmp_path,'a.png','white',(2,1)),png(tmp_path,'b.png','white',(2,1)))


def test_invalid_policy():
    for p in [{'max_body_regression':-1},{'min_global_improvement':0},{'min_hero_improvement':float('nan')},{'unknown':2}]:
        with pytest.raises(ValueError):validate_policy(p)


BASE={'all':3.,'top':7.,'body':1.,'bottom':5.}
IMPACT={'hero_changed_pixels':100,'hero_changed_fraction':1.}
@pytest.mark.parametrize('candidate,reason',[
    ({'all':3.01,'top':6.,'body':1.,'bottom':4.},'no_global_improvement_over_best'),
    ({'all':2.9,'top':6.,'body':1.006,'bottom':4.},'body_regression'),
    ({'all':2.9,'top':7.,'body':.5,'bottom':5.},'no_hero_improvement'),
])
def test_gates(candidate,reason):
    ok,reasons=acceptance(BASE,BASE,candidate,IMPACT)
    assert not ok and reason in reasons


def test_incumbent_must_improve():
    incumbent={'all':2.8,'top':6.,'body':1.,'bottom':4.}
    candidate={'all':2.9,'top':6.2,'body':1.,'bottom':4.1}
    ok,reasons=acceptance(BASE,incumbent,candidate,IMPACT)
    assert not ok and 'no_global_improvement_over_best' in reasons


def test_body_budget_not_cumulative():
    best={'all':2.9,'top':6.9,'body':1.004,'bottom':4.8}
    candidate={'all':2.8,'top':6.8,'body':1.008,'bottom':4.7}
    assert 'body_regression' in acceptance(BASE,best,candidate,IMPACT)[1]


def test_bad_icc_is_error(tmp_path):
    p=tmp_path/'bad.png';Image.new('RGB',(20,100),'white').save(p,icc_profile=b'invalid ICC profile')
    with pytest.raises((OSError,ImageCms.PyCMSError)): read_rgb(p)


def test_cli_failure_code(tmp_path):
    import subprocess
    p=subprocess.run([sys.executable,str(ROOT/'tools/compare_previews.py'),str(REF/'00_RGB_source.png'),
        str(REF/'01_ordinary_CMYK.png'),str(REF/'02_optimized_CMYK.png'),'--out',str(tmp_path),'--require-pass'],capture_output=True,text=True)
    assert p.returncode==2
    assert 'NO_MEASURABLE_IMPROVEMENT' in p.stdout

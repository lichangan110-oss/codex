/* Execute shipped JSX orchestration against a deterministic fake Illustrator DOM.
 * This is a control-flow regression test, NOT Illustrator compatibility acceptance.
 * Real pixel measurements are tested separately in Python against the supplied banner.
 */
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),vm=require('node:vm');
const crypto=require('node:crypto'),assert=require('node:assert/strict');
const project=path.resolve(__dirname,'..');let total=0;
function run(options={}){
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'vm14-host-')),pkg=path.join(tmp,'程序包'),sourceDir=path.join(tmp,'原稿');
 fs.mkdirSync(path.join(pkg,'src'),{recursive:true});fs.mkdirSync(sourceDir);
 fs.mkdirSync(path.join(pkg,'runtime/requests'),{recursive:true});fs.mkdirSync(path.join(pkg,'runtime/responses'));
 fs.mkdirSync(path.join(tmp,'Desktop'));
 fs.writeFileSync(path.join(pkg,'config.json'),JSON.stringify({maxExports:8,maxGroups:2,timeoutSeconds:5,step:3,fineStep:1,artboardIndex:-1}));
 const srcPath=path.join(sourceDir,'测试 原稿.ai');fs.writeFileSync(srcPath,JSON.stringify({mode:options.nonRGB?'CMYK':'RGB',values:[[70,40,0,0],[90,20,0,0]]}));
 const original=fs.readFileSync(srcPath),events=[],messages=[];let exported=0,evaluated=0,commits=0,bestPNG,sourceHash;
 function sha(p){return crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');}
 function dispatch(r){
  if(r.op==='ping')return {version:'1.4.0'};
  if(r.op==='hash')return {sha256:sha(r.path)};
  if(r.op==='source_audit')return {sha256:sha(r.path),fonts:options.missingFont?['MissingFont']:[],gradient_names:2};
  if(r.op==='structure'){
   let same=fs.readFileSync(r.before,'utf8')===fs.readFileSync(r.after,'utf8');
   fs.writeFileSync(r.report,JSON.stringify({equal:same,differences:same?[]:['mock structural change']}));return {equal:same};
  }
  if(r.op==='init'){bestPNG=r.baseline;sourceHash=r.source_hash;return {baseline:{all:3}};}
  if(r.op==='repeat')return {equal:fs.readFileSync(r.path,'utf8')===fs.readFileSync(bestPNG,'utf8')};
  if(r.op==='evaluate'){
   evaluated++;let accepted=!!options.acceptFirst && evaluated===1;
   return {accepted,reasons:accepted?[]:['no_global_improvement_over_best'],metrics:{all:accepted?2:4},
     impact:{hero_changed_pixels:100,hero_error_mass:1000}};
  }
  if(r.op==='commit'){commits++;bestPNG=r.png;fs.writeFileSync(path.join(r.job,'best_verified.json'),JSON.stringify(r));return {committed:true};}
  if(r.op==='publication_gate')return {accepted:commits>0&&!options.rejectFinal,reasons:['mock_gate']};
  if(r.op==='verify_best')return {equal:fs.readFileSync(r.path,'utf8')===fs.readFileSync(bestPNG,'utf8')};
  if(r.op==='finalize'){
   const status=r.interrupted?'PARTIAL':r.fallback?'NO_MEASURABLE_IMPROVEMENT':'PASS';
   assert.equal(sha(srcPath),sourceHash);fs.writeFileSync(path.join(r.job,'run_results.json'),JSON.stringify({status,fallback:r.fallback}));
   return {status,safe:true};
  }
  throw Error('Unsupported mock RPC '+r.op);
 }
 function File(p){if(!(this instanceof File))return new File(p);this.fsName=path.resolve(String(p));this.encoding='UTF-8';}
 Object.defineProperties(File.prototype,{name:{get(){return path.basename(this.fsName);}},parent:{get(){return new Folder(path.dirname(this.fsName));}},exists:{get(){return fs.existsSync(this.fsName);}},length:{get(){return this.exists?fs.statSync(this.fsName).size:0;}}});
 File.prototype.open=function(m){this.mode=m;if(m==='r')return this.exists;if(m==='w'){if(options.denyOutput && this.fsName.includes('STATUS'))return false;try{fs.writeFileSync(this.fsName,'');return true;}catch(e){return false;}}};
 File.prototype.write=function(s){fs.appendFileSync(this.fsName,s);};File.prototype.read=function(){return fs.readFileSync(this.fsName,'utf8');};File.prototype.close=function(){};
 File.prototype.copy=function(p){events.push(['copy',this.fsName,p]);fs.copyFileSync(this.fsName,p,fs.constants.COPYFILE_EXCL);return true;};
 File.prototype.rename=function(name){const dest=path.join(path.dirname(this.fsName),name);fs.renameSync(this.fsName,dest);this.fsName=dest;
  if(dest.includes(path.sep+'requests'+path.sep)&&dest.endsWith('.json')){
   const r=JSON.parse(fs.readFileSync(dest,'utf8'));let response;
   try{response={ok:true,id:r.id,...dispatch(r)};}catch(e){response={ok:false,id:r.id,error:e.message};}
   fs.writeFileSync(path.join(pkg,'runtime/responses',name),JSON.stringify(response));
  }return true;
 };
 function Folder(p){if(!(this instanceof Folder))return new Folder(p);this.fsName=path.resolve(p);}
 Object.defineProperties(Folder.prototype,{exists:{get(){return fs.existsSync(this.fsName);}},parent:{get(){return new Folder(path.dirname(this.fsName));}}});
 Folder.prototype.create=function(){try{fs.mkdirSync(this.fsName);return true;}catch(e){return false;}};
 Folder.desktop=new Folder(path.join(tmp,'Desktop'));
 const app={documents:[],version:'29.0.0-MOCK',redraw(){},textFonts:{getByName(n){if(n==='MissingFont')throw Error('missing');return {name:n};}}};
 function makeDoc(file){
  const data=JSON.parse(fs.readFileSync(file.fsName,'utf8'));
  const d={typename:'Document',name:file.name,fullName:file,saved:!options.unsaved,documentColorSpace:data.mode};
  const gradients=data.values.map((a,i)=>({name:'渐变'+i,type:'LINEAR',gradientStops:[0,1].map((_,s)=>({rampPoint:s*100,midPoint:50,opacity:100,color:data.mode==='CMYK'?{typename:'CMYKColor',cyan:a[0],magenta:a[1],yellow:a[2],black:a[3]}:{typename:'RGBColor',red:120,green:80,blue:220}}))}));
  d.gradients=gradients;d.artboards=[{name:'画板1',artboardRect:[0,1000,100,0]}];d.artboards.getActiveArtboardIndex=()=>0;d.artboards.setActiveArtboardIndex=i=>{assert.equal(i,0);};
  const l={typename:'Layer',name:'图层1',parent:d,visible:true,locked:!!options.locked,opacity:100,blendingMode:'Normal',printable:true,layers:[]};
  l.pageItems=gradients.map((g,i)=>({typename:'PathItem',parent:l,name:'主视觉'+i,uuid:'uuid'+i,
   geometricBounds:i?[0,140,100,0]:[data.badGeometry?1:0,1000,100,750],visibleBounds:i?[0,140,100,0]:[0,1000,100,750],
   hidden:false,locked:false,opacity:100,blendingMode:'Normal',clipping:false,filled:true,stroked:false,
   closed:true,strokeWidth:1,strokeDashes:[],strokeDashOffset:0,strokeCap:'BUTT',strokeJoin:'MITER',strokeMiterLimit:4,
   fillOverprint:false,strokeOverprint:false,evenodd:false,pathPoints:[],
   fillColor:{typename:'GradientColor',gradient:g,origin:[0,0],angle:0,length:100,hiliteAngle:0,hiliteLength:0,
    matrix:{mValueA:1,mValueB:0,mValueC:0,mValueD:1,mValueTX:0,mValueTY:0}}}));
  d.layers=[l];d.pageItems=l.pageItems;d.pathItems=l.pageItems;d.textFrames=[];
  d.save=()=>{assert.notEqual(file.fsName,srcPath,'NEVER save source');events.push(['save',file.fsName]);
   fs.writeFileSync(file.fsName,JSON.stringify({mode:d.documentColorSpace,badGeometry:!!options.corruptGeometry,values:gradients.map(g=>{let c=g.gradientStops[0].color;return [c.cyan,c.magenta,c.yellow,c.black];})}));};
  d.close=()=>{assert.notEqual(file.fsName,srcPath,'NEVER close source');};
  d.exportFile=(out,type,opt)=>{
   assert.notEqual(file.fsName,srcPath,'export a copy, not source');exported++;
   if(options.failExport || (options.failAfterAccept && commits>0))throw Error('simulated export failure');
   const state=gradients.map(g=>g.gradientStops.map(s=>s.color));
   fs.writeFileSync(out.fsName+'.png',JSON.stringify(state));
   if(options.stopAfterBaseline && out.fsName.endsWith('01_baseline_repeat'))fs.writeFileSync(path.join(path.dirname(out.fsName),'STOP.txt'),'stop');
  };
  return d;
 }
 app.open=f=>{const d=makeDoc(f);app.activeDocument=d;return d;};
 app.executeMenuCommand=cmd=>{assert.equal(cmd,'doc-color-cmyk');let d=app.activeDocument;assert.notEqual(d.fullName.fsName,srcPath);
  d.documentColorSpace='CMYK';if(options.corruptGeometry)d.pathItems[0].geometricBounds[0]+=1;d.gradients.forEach((g,i)=>g.gradientStops.forEach(s=>s.color={typename:'CMYKColor',cyan:dataInk(i)[0],magenta:dataInk(i)[1],yellow:0,black:0}));};
 function dataInk(i){return i?[90,20]:[70,40];}
 const source=makeDoc(new File(srcPath));app.activeDocument=source;app.documents=[source];
 const context=vm.createContext({File,Folder,app,alert:s=>messages.push(s),DocumentColorSpace:{RGB:'RGB',CMYK:'CMYK'},SaveOptions:{DONOTSAVECHANGES:0},ExportType:{PNG24:0},
  RGBColor:function(){this.typename='RGBColor';},CMYKColor:function(){this.typename='CMYKColor';},ExportOptionsPNG24:function(){},
  $:{fileName:path.join(pkg,'src/VM14_VisualMatch.jsx'),os:'Mock OS',sleep(){}}});
 for(const f of ['vm14_core.js','vm14_audit.jsxinc','VM14_VisualMatch.jsx']){
  vm.runInContext(fs.readFileSync(path.join(project,'src',f),'utf8').replace(/^#(?:target|include).*$/gm,''),context,{timeout:30000,filename:f});
 }
 assert.deepEqual(fs.readFileSync(srcPath),original,'source byte hash unchanged');assert.equal(app.activeDocument,source);
 const outputs=fs.readdirSync(sourceDir).filter(n=>n.startsWith('VisualMatch_')).map(n=>path.join(sourceDir,n));
 return {tmp,outputs,events,messages,exported,evaluated,commits};
}
function test(name,opts,check){const r=run(opts);try{check(r);total++;console.log('PASS '+name);}catch(e){console.error('MOCK files: '+r.tmp+'\n'+r.messages.join('\n'));throw e;}finally{fs.rmSync(r.tmp,{recursive:true,force:true});}}
test('rejected trials rollback to byte-identical baseline',{},r=>{assert.ok(r.evaluated>0);assert.equal(r.commits,0);let j=r.outputs[0];assert.deepEqual(fs.readFileSync(path.join(j,'01_ordinary_CMYK.ai')),fs.readFileSync(path.join(j,'02_optimized_CMYK.ai')));assert.equal(JSON.parse(fs.readFileSync(path.join(j,'run_results.json'))).status,'NO_MEASURABLE_IMPROVEMENT');assert.ok(r.exported<=8);});
test('accepted snapshot survives later rejection and roundtrip',{acceptFirst:true},r=>{assert.equal(r.commits,1);assert.equal(JSON.parse(fs.readFileSync(path.join(r.outputs[0],'run_results.json'))).status,'PASS');assert.ok(r.exported<=8);});
test('locked shared gradient is not searched',{locked:true},r=>{assert.equal(r.evaluated,0);assert.ok(fs.existsSync(path.join(r.outputs[0],'02_optimized_CMYK.ai')));});
test('unsaved RGB source fails before creating outputs',{unsaved:true},r=>{assert.equal(r.outputs.length,0);assert.equal(r.exported,0);});
test('missing original font stops before conversion',{missingFont:true},r=>{assert.equal(r.exported,0);assert.ok(r.messages.some(s=>s.includes('Missing original font')));});
test('export failure is ERROR and preserves source',{failExport:true},r=>{assert.ok(fs.existsSync(path.join(r.outputs[0],'ERROR.txt')));assert.ok(!fs.existsSync(path.join(r.outputs[0],'02_optimized_CMYK.ai')));});
test('STOP safely publishes a PARTIAL baseline',{stopAfterBaseline:true},r=>{assert.equal(r.evaluated,0);assert.equal(JSON.parse(fs.readFileSync(path.join(r.outputs[0],'run_results.json'))).status,'PARTIAL');});
test('failed final publication gate replaces accepted candidate with baseline',{acceptFirst:true,rejectFinal:true},r=>{assert.equal(r.commits,1);let j=r.outputs[0];assert.deepEqual(fs.readFileSync(path.join(j,'01_ordinary_CMYK.ai')),fs.readFileSync(path.join(j,'02_optimized_CMYK.ai')));});
test('non-RGB source fails before creating outputs',{nonRGB:true},r=>{assert.equal(r.outputs.length,0);assert.equal(r.exported,0);});
test('conversion geometry drift stops before optimization',{corruptGeometry:true},r=>{assert.equal(r.evaluated,0);assert.ok(fs.existsSync(path.join(r.outputs[0],'ERROR.txt')));});
test('late host failure preserves last committed snapshot',{acceptFirst:true,failAfterAccept:true},r=>{assert.equal(r.commits,1);let j=r.outputs[0];assert.ok(fs.existsSync(path.join(j,'best_verified.json')));assert.ok(fs.existsSync(path.join(j,'ERROR.txt')));assert.ok(!fs.existsSync(path.join(j,'02_optimized_CMYK.ai')));});
console.log(total+' host orchestration mock tests passed; Illustrator runtime remains untested.');

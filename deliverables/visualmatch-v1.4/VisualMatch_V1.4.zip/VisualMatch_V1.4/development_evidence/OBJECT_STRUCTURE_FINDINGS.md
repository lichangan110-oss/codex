# 原稿真实结构调查（只读）

文件 SHA-256：`741e1f1f0eaa7cf502c6b59f1f16c5669b5d8eb877de449c2bde4aa671259109`
原生私有数据解压 793,841 字节；90 条渐变定义记录、90 个不同名称（包括版本/外观备用记录，不等于 DOM 渐变数量）。
PDF 页面实际有 29 次 sh 绘制调用，类型含轴向 Type 2 与径向 Type 3；含透明 soft-mask。

|原生对象标识|渐变引用|私有数据行号|
|---|---|---:|
|hero_base|未命名的渐变|11574|
|hero_glow|未命名的渐变 2|11600|
|dark_ribbon|未命名的渐变 3|11642|
|light_ribbon|未命名的渐变 4|11674|
|ribbon_edge_glow|未命名的渐变 5|11700|
|v5_extended_footer_base|未命名的渐变 16|13289|
|footer_wave_main|未命名的渐变 17|13336|
|footer_secondary|未命名的渐变 18|13364|
|v4_C_footer_color_band|未命名的渐变 89|18918|

顶部主底板的 PDF 裁剪区域为 [0, 944.779, 566.93, 330.501]；底部主波形约在 y=0–197。
V1.3 collectRGB() 仅接受 RGBColor；GradientColor 色标未被采集，setColor() 也没有渐变分支。
V1.3 还按属性频率排序，用样本 ΔE76 接受修改，无真实导出图回滚门槛。
所以大面积渐变被遗漏，小面积颜色即使理论改善，整图也可能变差。
不得用 gradients.length==0 推断为网格/位图：本文件的原生渐变定义及对象引用已被直接读出。
运行时究竟哪些公开 DOM 对象暴露填充/描边，仍由 JSX 审计确认；不把 XMLUID 自动等同于 DOM name 或 uuid。
不修改私有流、不另存 PDF 冒充可编辑 AI、不替换文字或字体。

声明字体：AdobeSongStd-Light, SourceHanSansCN-Bold, SourceHanSansCN-Medium, SourceHanSansCN-Regular, SourceHanSansJP-Bold

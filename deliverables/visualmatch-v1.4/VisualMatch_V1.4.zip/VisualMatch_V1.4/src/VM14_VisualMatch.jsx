#target illustrator
#include "vm14_core.js"
#include "vm14_audit.jsxinc"
/* V1.4: retains V1.3 copy -> app.open -> doc-color-cmyk -> PNG/save workflow.
 * Color frequency and sample-Lab optimizer replaced with measured pixel transactions.
 * Source document is read-only. Every trial starts from the best verified AI copy.
 */
alert('VisualMatch V1.4 START\n脚本已启动。RGB 原稿不会被保存或改色。\n请先启动包内 Python worker。');
(function () {
    var C=VM14Core, root=new File($.fileName).parent.parent;
    var config={maxExports:80,maxGroups:8,timeoutSeconds:120,step:3,fineStep:1,artboardIndex:-1};
    var source=null,sourceFile=null,working=null,job=null,bridge=new Folder(root.fsName+'/runtime');
    var logLines=[],seq=0,exportCount=0,trialNumber=0,bestAI=null,bestPNG=null,baseline=null;
    var baselineAudit=null,sourceAudit=null,originalHash=null,interrupted=false,unsupportedCount=0;
    var session=(new Date()).getTime()+'_'+Math.floor(Math.random()*1000000), stage='BOOT';
    var desktopLog=new File(Folder.desktop.fsName+'/VisualMatch_V14_LAST_STATUS.txt');
    function write(file,text){file.encoding='UTF-8';if(!file.open('w'))throw Error('Cannot write '+file.fsName);try{file.write(text);}finally{file.close();}}
    function read(file){file.encoding='UTF-8';if(!file.open('r'))throw Error('Cannot read '+file.fsName);try{return file.read();}finally{file.close();}}
    function json(file,obj){write(file,C.stringify(obj));}
    function log(msg){var s=(new Date()).toString()+' | '+stage+' | '+msg;logLines.push(s);
        try{write(desktopLog,logLines.join('\n'));}catch(e){}
        if(job)write(new File(job.fsName+'/STATUS.txt'),logLines.join('\n'));}
    function stopRequested(){return job && new File(job.fsName+'/STOP.txt').exists;}
    function rpc(data,allowStop){
        data.id='vm14_'+session+'_'+(++seq);var requests=new Folder(bridge.fsName+'/requests');
        var responses=new Folder(bridge.fsName+'/responses');
        if(!requests.exists||!responses.exists)throw Error('Worker not ready. Run tools/worker.py first.');
        var temp=new File(requests.fsName+'/'+data.id+'.tmp');json(temp,data);
        if(!temp.rename(data.id+'.json'))throw Error('Cannot atomically submit worker request');
        var response=new File(responses.fsName+'/'+data.id+'.json'),start=(new Date()).getTime(),tick=0;
        while(!response.exists){
            if(allowStop && stopRequested())throw Error('USER_STOP');
            if((new Date()).getTime()-start>config.timeoutSeconds*1000)throw Error('Worker timeout: '+data.op);
            $.sleep(100);tick++;if(tick%10==0)app.redraw();response=new File(response.fsName);
        }
        var result=C.parse(read(response));
        if(result.id!=data.id||!result.ok)throw Error('Worker '+data.op+': '+(result.error||'response mismatch'));
        return result;
    }
    function freshFolder(parent,name){var f=new Folder(parent.fsName+'/'+name),n=0;while(f.exists)f=new Folder(parent.fsName+'/'+name+'_'+(++n));if(!f.create())throw Error('Cannot create '+f.fsName);return f;}
    function mode(d){return d.documentColorSpace==DocumentColorSpace.RGB?'RGB':d.documentColorSpace==DocumentColorSpace.CMYK?'CMYK':'UNKNOWN';}
    function copy(file,target){if(target.exists)throw Error('Refusing overwrite '+target.fsName);if(!file.copy(target.fsName))throw Error('Copy failed '+file.fsName);}
    function openCopy(file,target){copy(file,target);var d=app.open(target);app.activeDocument=d;
        if(d.fullName.fsName==sourceFile.fsName)throw Error('Source safety violation');
        d.artboards.setActiveArtboardIndex(config.artboardIndex);return d;}
    function closeWork(){if(working){working.close(SaveOptions.DONOTSAVECHANGES);working=null;}}
    function exportPNG(d,name){
        if(exportCount>=config.maxExports)throw Error('Export budget exceeded');
        var out=new File(job.fsName+'/'+name+'.png');if(out.exists)throw Error('PNG already exists '+out.fsName);
        d.artboards.setActiveArtboardIndex(config.artboardIndex);
        var o=new ExportOptionsPNG24();o.antiAliasing=true;o.artBoardClipping=true;o.transparency=false;
        o.matte=true;var white=new RGBColor();white.red=255;white.green=255;white.blue=255;o.matteColor=white;
        o.horizontalScale=100;o.verticalScale=100;
        app.redraw();d.exportFile(new File(job.fsName+'/'+name),ExportType.PNG24,o);exportCount++;
        out=new File(out.fsName);if(!out.exists||out.length==0)throw Error('Missing PNG after export');
        log('PNG '+name+'; export '+exportCount+'/'+config.maxExports);return out;
    }
    function tsv(name,headers,rows){var lines=[headers.join('\t')],i,j,a;
        for(i=0;i<rows.length;i++){a=[];for(j=0;j<headers.length;j++){var v=rows[i][headers[j]];
            if(typeof v=='object')v=C.stringify(v);a.push(String(v===null?'':v).replace(/[\t\r\n]/g,' '));}lines.push(a.join('\t'));}
        write(new File(job.fsName+'/'+name),lines.join('\n'));}
    function saveAudit(a,prefix){
        json(new File(job.fsName+'/'+prefix+'structure.json'),a.snapshot);
        tsv(prefix+'object_inventory.tsv',['path','uuid','type','name','geometricBounds','visibleBounds','hidden','locked',
            'effectiveVisible','effectiveLocked','opacity','blendingMode','clipped','clipping','maskAncestors','topArea','bodyArea','bottomArea'],a.inventory);
        tsv(prefix+'color_source_audit.tsv',['path','part','source','visible','locked','top_area','body_area','bottom_area'],a.colors);
        tsv(prefix+'unsupported_items.tsv',['path','type','reason'],a.unsupported);
    }
    function structure(before,after,label){
        return rpc({op:'structure',before:before.fsName,after:after.fsName,
                    report:new File(job.fsName+'/structure_'+label+'_diff.json').fsName},false);
    }
    function newInk(a){var n=new CMYKColor();n.cyan=a[0];n.magenta=a[1];n.yellow=a[2];n.black=a[3];return n;}
    function apply(a,g,values){
        var current=a.allGroups[g.key];if(!current||!current.eligible)throw Error('Color group no longer safely editable');
        if(current.owners.length!=g.owners.length)throw Error('Color group usage changed');
        var i,r,owner,col,gradient=null,seenGradient=null;
        for(i=0;i<g.owners.length;i++){
            owner=g.owners[i];r=a.refs[owner.path];
            if(!r||r.record.fingerprint!=owner.fingerprint)throw Error('Object hierarchy/geometry fingerprint mismatch '+owner.path);
            if(r.record.effectiveLocked||!r.record.effectiveVisible)throw Error('Protected object '+owner.path);
            if(r.obj.typename!='PathItem')throw Error('Only path colors editable');
            col=r.obj[owner.part];
            if(g.kind=='gradient'){
                if(col.typename!='GradientColor'||col.gradient.name!=g.gradient)throw Error('Gradient identity mismatch');
                if(seenGradient && seenGradient!=col.gradient)throw Error('Ambiguous duplicate gradient name');
                seenGradient=col.gradient;gradient=col.gradient;
            }else if(col.typename!='CMYKColor')throw Error('Expected CMYKColor');
        }
        if(g.kind=='gradient'){
            if(gradient.gradientStops.length!=values.length)throw Error('Gradient stop count mismatch');
            for(i=0;i<values.length;i++)gradient.gradientStops[i].color=newInk(values[i]);
        }else a.refs[g.owners[0].path].obj[g.owners[0].part]=newInk(values[0]);
        // Preserve gradient geometry, stop positions/opacities, names and associations.
    }
    function trial(g,values,kind){
        if(stopRequested()){interrupted=true;return null;}
        if(exportCount>=config.maxExports-1)return null; // Reserve final round-trip verification.
        trialNumber++;var num=('0000'+trialNumber).slice(-4),stem='trials/trial_'+num;
        var ai=new File(job.fsName+'/'+stem+'.ai'),png,measurement,a,beforeValues,actualValues,vi,vj;
        stage='TRIAL '+num+' '+kind;log(g.key);
        try{
            working=openCopy(bestAI,ai);a=VM14Audit(working,config.artboardIndex,null);
            var group=a.allGroups[g.key];if(!group)throw Error('Missing group');beforeValues=group.values;
            apply(a,g,values);
            var after=VM14Audit(working,config.artboardIndex,null);
            var sf=new File(job.fsName+'/'+stem+'_structure.json');json(sf,after.snapshot);
            if(!structure(new File(job.fsName+'/structure.json'),sf,'trial_'+num+'_pre').equal)throw Error('Structure changed before save');
            working.save();closeWork();
            working=app.open(ai);app.activeDocument=working;working.artboards.setActiveArtboardIndex(config.artboardIndex);
            if(mode(working)!='CMYK')throw Error('Trial is not CMYK');
            after=VM14Audit(working,config.artboardIndex,null);json(sf,after.snapshot);
            if(!structure(new File(job.fsName+'/structure.json'),sf,'trial_'+num).equal)throw Error('Structure changed on save/reopen');
            if(!after.allGroups[g.key])throw Error('Edited color source disappeared after reopen');
            actualValues=after.allGroups[g.key].values;
            if(actualValues.length!=values.length)throw Error('Color stop count changed on reopen');
            for(vi=0;vi<values.length;vi++)for(vj=0;vj<4;vj++)
                if(Math.abs(actualValues[vi][vj]-values[vi][vj])>.02)throw Error('CMYK setter/readback mismatch');
            png=exportPNG(working,stem);closeWork();
            measurement=rpc({op:'evaluate',job:job.fsName,trial:trialNumber,kind:kind,group:g.key,
                before:beforeValues,after:actualValues,candidate_png:png.fsName,candidate_ai:ai.fsName,structure_ok:true},false);
            if(measurement.accepted){
                rpc({op:'commit',job:job.fsName,trial:trialNumber,ai:ai.fsName,png:png.fsName},false);
                bestAI=ai;bestPNG=png;g.values=actualValues;log('ACCEPT '+C.stringify(measurement.metrics));
            }else log('ROLLBACK: discarded trial, best file unchanged. '+measurement.reasons.join(','));
            g.contribution=measurement.impact.hero_error_mass;
            return measurement;
        }catch(e){
            closeWork();log('TRIAL ERROR / ROLLBACK '+String(e));
            // An unexplained host/IPC/structure failure stops the search; never silently publish as PASS.
            interrupted=true;throw e;
        }
    }
    function finish(fallback){
        stage='FINALIZE';
        var outAI=new File(job.fsName+'/02_optimized_CMYK.ai'),outPNG=new File(job.fsName+'/02_optimized_CMYK.png');
        copy(fallback?new File(job.fsName+'/01_ordinary_CMYK.ai'):bestAI,outAI);
        copy(fallback?new File(job.fsName+'/01_ordinary_CMYK.png'):bestPNG,outPNG);
        var result=rpc({op:'finalize',job:job.fsName,fallback:fallback,interrupted:interrupted,
            structure_report:new File(job.fsName+'/structure_final_diff.json').fsName,
            unsupported_count:unsupportedCount},false);
        log('RESULT '+result.status+'; exports='+exportCount+'; integrity/structure/file-pair='+result.safe);
        alert('VisualMatch V1.4 '+result.status+'\n\n'+job.fsName+'\n\n请查看 FINAL_REPORT.md、STATUS.txt 与分区色差报告。');
    }
    log('Illustrator '+app.version);
    try{
        var cfg=new File(root.fsName+'/config.json');if(cfg.exists){var custom=C.parse(read(cfg)),k;
            for(k in custom)if(Object.prototype.hasOwnProperty.call(custom,k)){if(typeof config[k]=='undefined')throw Error('Unknown config '+k);config[k]=custom[k];}}
        for(k in config)if(Object.prototype.hasOwnProperty.call(config,k) && (typeof config[k]!='number'||!isFinite(config[k])))throw Error('Config fields must be finite numbers: '+k);
        if(config.artboardIndex < -1)throw Error('artboardIndex must be -1 or a nonnegative integer');
        if(config.maxExports<5||config.maxExports>500||config.maxExports!=Math.floor(config.maxExports)||
           config.maxGroups<1||config.maxGroups>8||config.maxGroups!=Math.floor(config.maxGroups)||
           config.step<=0||config.step>10||config.fineStep<=0||config.fineStep>5||config.timeoutSeconds<5)throw Error('Invalid config limits');
        if(parseInt(app.version,10)!=29)throw Error('Target is Illustrator 2025 (29.x); other versions require separate acceptance');
        if(app.documents.length<1)throw Error('Open a saved RGB .ai first');source=app.activeDocument;
        if(!source.saved||mode(source)!='RGB')throw Error('Source must be a saved RGB document. Save manually first.');
        sourceFile=source.fullName;if(!/\.ai$/i.test(sourceFile.name))throw Error('Source must be .ai');
        if(config.artboardIndex<0)config.artboardIndex=source.artboards.getActiveArtboardIndex();
        if(config.artboardIndex>=source.artboards.length||config.artboardIndex!=Math.floor(config.artboardIndex))throw Error('Invalid artboard index');
        job=freshFolder(sourceFile.parent,'VisualMatch_V14_'+session);freshFolder(job,'trials');
        log('Output '+job.fsName+'; active artboard '+config.artboardIndex);
        var ping=rpc({op:'ping'},false);if(ping.version!='1.4.0')throw Error('Worker version mismatch');
        originalHash=rpc({op:'hash',path:sourceFile.fsName},false).sha256;
        stage='SOURCE FILE AUDIT';
        var nativeInfo=rpc({op:'source_audit',path:sourceFile.fsName,out:job.fsName+'/source_file_evidence'},false);
        if(nativeInfo.sha256!=originalHash)throw Error('Source changed during startup');
        var nf;for(nf=0;nf<nativeInfo.fonts.length;nf++){
            try{app.textFonts.getByName(nativeInfo.fonts[nf]);}
            catch(fontError){throw Error('Missing original font: '+nativeInfo.fonts[nf]+'. Install it; never substitute.');}
        }
        stage='SOURCE AUDIT';sourceAudit=VM14Audit(source,config.artboardIndex,log);saveAudit(sourceAudit,'source_');
        // Check every font name exposed by the loaded document; never substitute or outline.
        var si,sr,st;
        for(si=0;si<sourceAudit.snapshot.items.length;si++){
            sr=sourceAudit.snapshot.items[si];if(sr.type=='TextFrame')for(st=0;st<sr.details.styles.length;st++)
                app.textFonts.getByName(sr.details.styles[st].style.font);
        }
        var manifest={version:'1.4.0',illustrator_version:app.version,os:$.os,source:sourceFile.fsName,source_sha256_before:originalHash,
            artboard_index:config.artboardIndex,artboard_rect:sourceAudit.artboard,artboard_count:source.artboards.length,
            "export":{scale:100,antiAliasing:true,artBoardClipping:true,transparency:false,matte:'white'},
            color_settings:'Illustrator current settings retained; profile UI must be checked by operator; untagged PNG assumed sRGB',
            source_native_gradients:sourceAudit.nativeGradientCount,original_fonts:nativeInfo.fonts,config:config,
            structural_scope:'Public DOM snapshots; private effects/opacity-mask internals require manual acceptance',
            fonts:'Loaded document names verified present; confirm no substitution warning when opening original'};
        json(new File(job.fsName+'/run_manifest.json'),manifest);
        // Export a read-only disk copy to avoid even changing the source active artboard.
        stage='RGB PREVIEW';working=openCopy(sourceFile,new File(job.fsName+'/00_RGB_readonly_copy.ai'));
        exportPNG(working,'00_RGB_source');closeWork();
        stage='ORDINARY CONVERSION';baseline=new File(job.fsName+'/01_ordinary_CMYK.ai');
        working=openCopy(sourceFile,baseline);app.redraw();app.executeMenuCommand('doc-color-cmyk');app.redraw();
        if(mode(working)!='CMYK')throw Error('V1.3 CMYK switch failed');
        working.save();closeWork();working=app.open(baseline);app.activeDocument=working;
        baselineAudit=VM14Audit(working,config.artboardIndex,log);saveAudit(baselineAudit,'');unsupportedCount=baselineAudit.unsupported.length;
        if(!structure(new File(job.fsName+'/source_structure.json'),new File(job.fsName+'/structure.json'),'conversion').equal)
            throw Error('Conversion changed structure/text/font/geometry. See structure_conversion_diff.json');
        exportPNG(working,'01_ordinary_CMYK');
        var repeated=exportPNG(working,'01_baseline_repeat');closeWork();
        bestAI=baseline;bestPNG=new File(job.fsName+'/01_ordinary_CMYK.png');
        rpc({op:'init',job:job.fsName,rgb:new File(job.fsName+'/00_RGB_source.png').fsName,
             baseline:bestPNG.fsName,baseline_ai:baseline.fsName,source:sourceFile.fsName,source_hash:originalHash},false);
        // Byte equality is intentionally strict: nondeterministic export invalidates tiny numerical gains.
        var repeatCheck=rpc({op:'repeat',job:job.fsName,path:repeated.fsName},false);
        if(!repeatCheck.equal)throw Error('Baseline PNG pixels differ between repeated exports');
        var groups=[],ranked=baselineAudit.groups.slice(0),selected={},rankIndex=0,side=0,i,ch,dir,vals,result,eligible=[],stop;
        // Alternate largest top and bottom candidates so one region cannot consume all slots.
        while(groups.length<config.maxGroups && groups.length<ranked.length){
            var chosen=null,largest=-1;
            for(i=0;i<ranked.length;i++)if(!selected[ranked[i].key]){
                var area=side==0?ranked[i].topArea:ranked[i].bottomArea;
                if(area>largest){largest=area;chosen=ranked[i];}
            }
            if(!chosen)break;groups.push(chosen);selected[chosen.key]=true;side=1-side;
        }
        stage='VISIBLE CONTRIBUTION PROBES';log('Geometric candidates '+groups.length+'; gradient count does not define appearance');
        for(i=0;i<groups.length;i++){
            if(stopRequested()){interrupted=true;break;}
            // Find a non-clamped small probe. Its actual PNG effect determines ranking.
            vals=C.shifted(groups[i].values,1,config.step,-1);
            if(C.same(vals,groups[i].values))vals=C.shifted(groups[i].values,1,-config.step,-1);
            result=trial(groups[i],vals,'probe');
            if(result && result.impact.hero_changed_pixels>=4)eligible.push(groups[i]);
            else log('No demonstrated hero contribution: '+groups[i].key);
        }
        eligible.sort(function(a,b){return b.contribution-a.contribution;});
        // Round-robin by parameter gives each visible candidate a budget share.
        for(ch=0;ch<4&&!interrupted;ch++)for(dir=-1;dir<=1&&!interrupted;dir+=2)for(i=0;i<eligible.length&&!interrupted;i++){
            vals=C.shifted(eligible[i].values,ch,dir*config.step,-1);
            if(!C.same(vals,eligible[i].values))trial(eligible[i],vals,'coarse_all_stops');
        }
        // Spend remaining exports on individual gradient stop adjustments, never ramp/opacity/geometry.
        for(stop=0;stop<8&&!interrupted&&exportCount<config.maxExports-1;stop++)for(i=0;i<eligible.length&&!interrupted;i++){
            if(stop>=eligible[i].values.length)continue;
            for(ch=0;ch<4&&!interrupted;ch++)for(dir=-1;dir<=1&&!interrupted;dir+=2){
                vals=C.shifted(eligible[i].values,ch,dir*config.fineStep,stop);
                if(!C.same(vals,eligible[i].values))trial(eligible[i],vals,'fine_stop_'+stop);
            }
        }
        stage='FINAL READBACK';working=app.open(bestAI);app.activeDocument=working;
        var finalAudit=VM14Audit(working,config.artboardIndex,null);
        json(new File(job.fsName+'/final_structure.json'),finalAudit.snapshot);
        var finalDiff=structure(new File(job.fsName+'/source_structure.json'),new File(job.fsName+'/final_structure.json'),'final');
        if(!finalDiff.equal)throw Error('Final structural verification failed');
        var finalPNG=exportPNG(working,'final_readback');closeWork();
        var check=rpc({op:'verify_best',job:job.fsName,path:finalPNG.fsName},false);
        if(!check.equal)throw Error('Best AI no longer reproduces its measured PNG');
        var gate=rpc({op:'publication_gate',job:job.fsName,path:finalPNG.fsName},false);
        var fallback=bestAI.fsName==baseline.fsName || !gate.accepted;
        if(fallback){
            log('FINAL GATE: fallback_baseline '+gate.reasons.join(','));
            json(new File(job.fsName+'/final_structure.json'),baselineAudit.snapshot);
            if(!structure(new File(job.fsName+'/source_structure.json'),new File(job.fsName+'/final_structure.json'),'final').equal)
                throw Error('Fallback baseline structural check failed');
        }
        finish(fallback);
    }catch(fatal){
        interrupted=true;try{closeWork();}catch(closeError){}
        try{log('ERROR '+String(fatal)+' line '+(fatal.line||'?'));}catch(logError){}
        if(job){
            try{write(new File(job.fsName+'/ERROR.txt'),String(fatal)+'\nBest verified AI: '+(bestAI?bestAI.fsName:'none'));
                write(new File(job.fsName+'/FINAL_REPORT.md'),'# VisualMatch V1.4\n\n结论：ERROR\n\n'+String(fatal)+'\n\n源稿未由脚本保存。已验证最佳快照见 best_verified.json；未生成经完整验收的最终稿。\n');
                if(sourceFile&&originalHash){var h=rpc({op:'hash',path:sourceFile.fsName},false).sha256;
                    json(new File(job.fsName+'/source_integrity_on_error.json'),{before:originalHash,after:h,unchanged:h==originalHash});}
            }catch(reportError){}
        }
        alert('VisualMatch V1.4 ERROR\n'+String(fatal)+'\n\n'+(job?job.fsName:desktopLog.fsName)+'\n源稿未由脚本保存；查看日志后重试。');
    }finally{try{if(source)app.activeDocument=source;}catch(ignore){}}
})();

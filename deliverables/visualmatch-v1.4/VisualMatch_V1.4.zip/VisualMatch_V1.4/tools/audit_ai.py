"""Read-only AI/PDF evidence extraction. Does not pretend PDF objects are Illustrator DOM items."""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import re
from pathlib import Path
from collections import Counter
from pypdf import PdfReader
from pypdf.generic import ContentStream
import zstandard


def audit(path, out):
    path=Path(path);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    raw=path.read_bytes();before=hashlib.sha256(raw).hexdigest();reader=PdfReader(io.BytesIO(raw));page=reader.pages[0]
    private=page['/PieceInfo']['/Illustrator']['/Private']
    blocks=b''.join(private['/AIPrivateData'+str(i)].get_object().get_data() for i in range(1,int(private['/NumBlock'])+1))
    magic=blocks.index(b'\x28\xb5\x2f\xfd')
    with zstandard.ZstdDecompressor().stream_reader(io.BytesIO(blocks[magic:])) as stream:
        data=stream.read(64*1024*1024+1)
    if len(data)>64*1024*1024: raise ValueError('Private-data safety limit exceeded')
    native=data.decode('utf-8',errors='replace').replace('\r\n','\n').replace('\r','\n')
    (out/'native_ai_private.txt').write_text(native,encoding='utf-8')
    definitions=[]
    for match in re.finditer(r'^\(([^\n]+?)\) ([01]) (\d+) Bd\s*$',native,re.M):
        definitions.append({'name':match[1],'kind':'linear' if match[2]=='0' else 'radial',
                            'stops':int(match[3]),'line':native.count('\n',0,match.start())+1})
    # These are serialized records, including version/appearance alternatives, NOT DOM counts.
    objects=[];last=0
    for match in re.finditer(r'%_/XMLUID : \(([^\n]+?)\)',native):
        fragment=native[last:match.start()];last=match.end()
        uses=list(re.finditer(r'^1 \(([^\n]+?)\).*? Bg\s*$',fragment,re.M))
        if uses:
            objects.append({'xmluid':match[1],'gradient':uses[-1][1],
                            'line':native.count('\n',0,match.start())+1,
                            'evidence':fragment[max(0,uses[-1].start()-350):].strip()})
    main=[o for o in objects if o['xmluid'] in ['hero_base','hero_glow','dark_ribbon','light_ribbon',
        'ribbon_edge_glow','v5_extended_footer_base','footer_wave_main','footer_secondary','v4_C_footer_color_band']]
    operations=ContentStream(page.get_contents(),reader).operations
    shadings=[]
    for i,(args,op) in enumerate(operations):
        if op==b'sh':
            s=page['/Resources']['/Shading'][args[0]].get_object()
            shadings.append({'name':str(args[0]),'shading_type':int(s['/ShadingType']),
                'color_space':str(s['/ColorSpace']),
                'preceding_operations':[str(a)+' '+b.decode() for a,b in operations[max(0,i-16):i+1]]})
    ext=page['/Resources'].get('/ExtGState',{})
    masks=[str(k) for k,v in ext.items() if str(v.get_object().get('/SMask','/None'))!='/None']
    font_block=re.search(r'%%DocumentFonts: (.*?)(?=%%DocumentNeededFonts:)',native,re.S)
    fonts=[]
    if font_block:
        fonts=[re.sub(r'-(?:GBpc-EUC-H|90ms-RKSJ-[HV])$','',line.removeprefix('%%+ ').strip())
               for line in font_block[1].strip().splitlines()]
        fonts=sorted(set(fonts))
    summary={'source':path.name,'sha256_before':before,'sha256_after':hashlib.sha256(path.read_bytes()).hexdigest(),
        'page_count':len(reader.pages),'mediabox':list(map(float,page.mediabox)),
        'native_private_bytes':len(data),'native_gradient_definition_records':len(definitions),
        'native_gradient_names':len({d['name'] for d in definitions}),
        'native_gradient_types':dict(Counter(d['kind'] for d in definitions)),
        'main_visual_objects':main,'gradient_definitions':definitions,'fonts':fonts,
        'page_shading_paints':len(shadings),'page_shading_types':dict(Counter(s['shading_type'] for s in shadings)),
        'page_soft_mask_states':masks,'shading_paints':shadings,
        'limits':'Read-only private serialization/PDF evidence. Native record counts are not doc.gradients.length. Live DOM, clipping, font loading and color setters require Illustrator audit.'}
    (out/'ai_structure_evidence.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'native_gradient_definitions.json').write_text(json.dumps(definitions,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# 原稿真实结构调查（只读）','',f'文件 SHA-256：`{before}`',
        f"原生私有数据解压 {len(data):,} 字节；{len(definitions)} 条渐变定义记录、{summary['native_gradient_names']} 个不同名称（包括版本/外观备用记录，不等于 DOM 渐变数量）。",
        f"PDF 页面实际有 {len(shadings)} 次 sh 绘制调用，类型含轴向 Type 2 与径向 Type 3；含透明 soft-mask。",'',
        '|原生对象标识|渐变引用|私有数据行号|','|---|---|---:|']
    lines += [f"|{o['xmluid']}|{o['gradient']}|{o['line']}|" for o in main]
    lines+=['','顶部主底板的 PDF 裁剪区域为 [0, 944.779, 566.93, 330.501]；底部主波形约在 y=0–197。',
        'V1.3 collectRGB() 仅接受 RGBColor；GradientColor 色标未被采集，setColor() 也没有渐变分支。',
        'V1.3 还按属性频率排序，用样本 ΔE76 接受修改，无真实导出图回滚门槛。',
        '所以大面积渐变被遗漏，小面积颜色即使理论改善，整图也可能变差。',
        '不得用 gradients.length==0 推断为网格/位图：本文件的原生渐变定义及对象引用已被直接读出。',
        '运行时究竟哪些公开 DOM 对象暴露填充/描边，仍由 JSX 审计确认；不把 XMLUID 自动等同于 DOM name 或 uuid。',
        '不修改私有流、不另存 PDF 冒充可编辑 AI、不替换文字或字体。',
        '', '声明字体：'+', '.join(fonts)]
    (out/'OBJECT_STRUCTURE_FINDINGS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return summary

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('ai',type=Path);ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();r=audit(args.ai,args.out)
    print(json.dumps({k:r[k] for k in ['sha256_before','native_gradient_definition_records','native_gradient_names','page_shading_paints','fonts']},ensure_ascii=False,indent=2))

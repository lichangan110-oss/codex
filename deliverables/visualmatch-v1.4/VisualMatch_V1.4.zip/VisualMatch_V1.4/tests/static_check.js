/* Parse actual shipped scripts as ECMAScript 3, not merely current Node syntax. */
const fs=require('node:fs');const path=require('node:path');
const acorn=require(process.env.VM14_ACORN || 'acorn');
const root=path.resolve(__dirname,'..');
const files=['src/vm14_core.js','src/vm14_audit.jsxinc','src/VM14_VisualMatch.jsx'];
for(const name of files){
 const text=fs.readFileSync(path.join(root,name),'utf8').replace(/^#(?:target|include).*$/gm,'');
 acorn.parse(text,{ecmaVersion:3,allowReserved:"never"});
 console.log('ES3 PASS '+name);
}

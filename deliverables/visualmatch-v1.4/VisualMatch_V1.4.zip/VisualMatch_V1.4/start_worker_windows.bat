@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  echo Run setup_windows.bat first.
  pause
  exit /b 1
)
.venv\Scripts\python.exe tools\worker.py
if errorlevel 1 (
  echo Worker stopped with an error. See the message above and runtime\worker_errors.log.
  pause
  exit /b 1
)

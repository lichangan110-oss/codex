@echo off
setlocal
cd /d "%~dp0"
py -3.12 -m venv .venv
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip install -r tools\requirements.lock.txt
if errorlevel 1 goto fail
.venv\Scripts\python.exe -m pip check
if errorlevel 1 goto fail
echo Setup complete. Start start_worker_windows.bat, then run src\VM14_VisualMatch.jsx in Illustrator.
pause
exit /b 0
:fail
echo Setup failed. Keep this window for diagnostics. Python 3.12 64-bit is required.
pause
exit /b 1

"""Local, network-free file IPC oracle for Illustrator ExtendScript. Start before JSX."""
from __future__ import annotations
import argparse
import csv
import json
import os
import re
import time
import traceback
from pathlib import Path
from compare_previews import Oracle, acceptance, compare, sha256, validate_policy, read_rgb
import numpy as np


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def atomic_json(path, data):
    path=Path(path)
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    os.replace(tmp,path)


def structure_diff(a, b, path='$'):
    """Report every difference; UUID excluded by JSX, geometry tolerance 0.001pt."""
    out=[]
    if isinstance(a,dict) and isinstance(b,dict):
        for k in sorted(set(a)|set(b)):
            if k not in a or k not in b: out.append({'path':path+'.'+k,'before':a.get(k),'after':b.get(k)})
            else: out.extend(structure_diff(a[k],b[k],path+'.'+k))
    elif isinstance(a,list) and isinstance(b,list):
        if len(a)!=len(b): out.append({'path':path+'.length','before':len(a),'after':len(b)})
        for i,(x,y) in enumerate(zip(a,b)): out.extend(structure_diff(x,y,path+'['+str(i)+']'))
    elif isinstance(a,(float,int)) and not isinstance(a,bool) and isinstance(b,(float,int)) and not isinstance(b,bool):
        if abs(a-b) > .001: out.append({'path':path,'before':a,'after':b})
    elif a!=b or type(a)!=type(b): out.append({'path':path,'before':a,'after':b})
    return out


class Worker:
    def __init__(self): self.sessions={}

    def dispatch(self,r):
        op=r['op']
        if op=='ping': return {'version':'1.4.0','python_ready':True}
        if op=='hash': return {'sha256':sha256(r['path'])}
        if op=='source_audit':
            from audit_ai import audit
            evidence=audit(r['path'],r['out'])
            return {'fonts':evidence['fonts'],'sha256':evidence['sha256_before'],
                    'gradient_names':evidence['native_gradient_names']}
        if op=='structure':
            differences=structure_diff(load(r['before']),load(r['after']))
            result={'equal':not differences,'difference_count':len(differences),'differences':differences}
            atomic_json(r['report'],result)
            return {'equal':result['equal'],'difference_count':len(differences)}
        if op=='init':
            job=Path(r['job']).resolve()
            policy=validate_policy(r.get('policy'))
            if sha256(r['source'])!=r['source_hash']: raise ValueError('Source hash changed before init')
            oracle=Oracle(r['rgb'],r['baseline'])
            self.sessions[str(job)]={'oracle':oracle,'policy':policy,'best_metrics':oracle.baseline,
                'best_png':r['baseline'],'source':r['source'],'source_hash':r['source_hash'],
                'trace':[], 'pending':{}, 'best_ai':r.get('baseline_ai'),
                'best_ai_hash':sha256(r['baseline_ai']) if r.get('baseline_ai') else None}
            self.write_trace(job,self.sessions[str(job)])
            if r.get('baseline_ai'):
                atomic_json(job/'best_verified.json',{'ai':r['baseline_ai'],'png':r['baseline'],
                    'metrics':oracle.baseline,'trial':0,'ai_sha256':sha256(r['baseline_ai'])})
            return {'baseline':oracle.baseline,'source_hash':sha256(r['source'])}
        key=str(Path(r['job']).resolve())
        if key not in self.sessions: raise ValueError('Session missing; restart the JSX run after worker restart')
        s=self.sessions[key]; job=Path(key)
        if op=='publication_gate':
            metrics,impact,_,_=s['oracle'].measure(r['path'])
            accepted,reasons=acceptance(s['oracle'].baseline,s['oracle'].baseline,metrics,impact,s['policy'])
            return {'accepted':accepted,'reasons':reasons,'metrics':metrics}
        if op in ('repeat', 'verify_best'):
            previous=s['oracle'].base if op=='repeat' else read_rgb(s['best_png'])[0]
            image,meta=read_rgb(r['path'])
            s['oracle']._check(image,meta)
            return {'equal':bool(np.array_equal(previous,image))}
        if op=='evaluate':
            metrics,impact,meta,_=s['oracle'].measure(r['candidate_png'],s['best_png'])
            accepted,reasons=acceptance(s['oracle'].baseline,s['best_metrics'],metrics,impact,s['policy'])
            if not r.get('structure_ok',False): accepted=False;reasons.append('structure_check_failed')
            item={'trial':r['trial'],'kind':r['kind'],'group':r['group'],'before':r['before'],
                  'after':r['after'],'metrics':metrics,'impact':impact,'acceptable':accepted,
                  'accepted':False,'reasons':reasons,'candidate_png':r['candidate_png'],
                  'png_sha256':meta['sha256'],'ai_sha256':sha256(r['candidate_ai'])}
            s['trace'].append(item)
            s['pending'][str(r['trial'])]=item
            self.write_trace(job,s)
            return {'accepted':accepted,'reasons':reasons,'metrics':metrics,'impact':impact}
        if op=='commit':
            item=s['pending'].pop(str(r['trial']))
            if not item['acceptable']: raise ValueError('Cannot commit a rejected candidate')
            if sha256(r['png'])!=item['png_sha256'] or sha256(r['ai'])!=item['ai_sha256']:
                raise ValueError('Candidate files changed between evaluate and commit')
            if sha256(s['source'])!=s['source_hash']: raise ValueError('Source hash changed; abort')
            s['best_metrics']=item['metrics'];s['best_png']=r['png'];item['accepted']=True
            s['best_ai']=r['ai'];s['best_ai_hash']=item['ai_sha256']
            self.write_trace(job,s)
            atomic_json(job/'best_verified.json',{'ai':r['ai'],'png':r['png'],'metrics':item['metrics'],
                                                  'trial':item['trial'],'ai_sha256':item['ai_sha256']})
            return {'committed':True}
        if op=='finalize':
            source_after=sha256(s['source'])
            result=compare(job/'00_RGB_source.png',job/'01_ordinary_CMYK.png',
                           job/'02_optimized_CMYK.png',job,s['policy'])
            structural=load(r['structure_report'])
            expected_png=job/'01_ordinary_CMYK.png' if r.get('fallback') else Path(s['best_png'])
            expected_ai=job/'01_ordinary_CMYK.ai' if r.get('fallback') else Path(s['best_ai'])
            paired=(sha256(job/'02_optimized_CMYK.png')==sha256(expected_png) and
                    sha256(job/'02_optimized_CMYK.ai')==sha256(expected_ai))
            if not r.get('fallback'):
                paired=paired and sha256(expected_ai)==s['best_ai_hash']
            safe=source_after==s['source_hash'] and structural['equal'] and paired
            if not safe: result['status']='ERROR'
            elif r.get('interrupted'): result['status']='PARTIAL'
            # A baseline fallback is honest and never labelled PASS.
            elif r.get('fallback'): result['status']='NO_MEASURABLE_IMPROVEMENT'
            result['source_sha256_before']=s['source_hash'];result['source_sha256_after']=source_after
            result['source_unchanged']=source_after==s['source_hash']
            result['structure_equal']=structural['equal'];result['verified_file_pair']=paired;result['fallback_baseline']=r.get('fallback',False)
            result['accepted_trials']=sum(t['accepted'] for t in s['trace'])
            result['candidate_exports']=len(s['trace']);result['unsupported_count']=r.get('unsupported_count')
            atomic_json(job/'run_results.json',result)
            manifest=load(job/'run_manifest.json')
            manifest.update({'result':result['status'],'source_sha256_after':source_after,
                             'source_unchanged':result['source_unchanged'],
                             'output_sha256':{n:sha256(job/n) for n in ['01_ordinary_CMYK.ai','02_optimized_CMYK.ai',
                                '00_RGB_source.png','01_ordinary_CMYK.png','02_optimized_CMYK.png']}})
            atomic_json(job/'run_manifest.json',manifest)
            lines=['# VisualMatch V1.4 本次运行报告','',f"结论：**{result['status']}**",'',
                   f"原稿 SHA-256 未变：{result['source_unchanged']}；公开 DOM 结构字段一致：{result['structure_equal']}。",
                   f"已接受 {result['accepted_trials']} 次候选；回退普通稿：{result['fallback_baseline']}。",'',
                   '|区域|普通 ΔE00|输出 ΔE00|改善|','|---|---:|---:|---:|']
            for row in result['metrics']:
                lines.append(f"|{row['region']}|{row['ordinary_mean_DE00']:.6f}|{row['optimized_mean_DE00']:.6f}|{row['improvement_abs']:.6f}|")
            lines+=['',f"变化像素：{result['changed_pixels']}（{result['changed_pixel_percent']:.4f}%）。",
                    f"未支持对象/颜色项：{r.get('unsupported_count')}，见 unsupported_items.tsv。",
                    '逐次对象、前后 CMYK、分区评分与回滚原因见 optimization_trace.tsv。',
                    '完整结构差异见 structure_final_diff.json；公开 DOM 不等于完整私有外观栈，需在 Illustrator 人工确认。',
                    '目标为屏幕 PNG 相对匹配；整图下降 3%、主视觉加权下降 5% 是目标，不保证达成。',
                    '字体缺失、透明蒙版、不可读插件/网格/外观栈不进行破坏性转换。',
                    '输出是 Illustrator 本次导出的结果；开发环境未替代本次实机行为。']
            (job/'FINAL_REPORT.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
            self.write_trace(job,s)
            return {'status':result['status'],'safe':safe}
        raise ValueError('Unknown operation: '+op)

    def write_trace(self,job,s):
        atomic_json(job/'optimization_trace.json',s['trace'])
        fields=['trial','kind','group','before','after','accepted','reasons','global_mean_DE00',
                'top_mean_DE00','body_mean_DE00','bottom_mean_DE00','changed_pixels','hero_changed_pixels']
        for name in ['optimization_trace.tsv','color_matching_report.tsv']:
            with (job/name).open('w',encoding='utf-8-sig',newline='') as f:
                w=csv.DictWriter(f,fieldnames=fields,delimiter='\t');w.writeheader()
                for t in s['trace']:
                    row={k:t[k] for k in fields[:7]}
                    for k in ('group','before','after','reasons'): row[k]=json.dumps(row[k],ensure_ascii=False)
                    row.update({('global' if k=='all' else k)+'_mean_DE00':v for k,v in t['metrics'].items()})
                    row.update({k:t['impact'][k] for k in ('changed_pixels','hero_changed_pixels')})
                    w.writerow(row)


def serve(bridge):
    bridge=Path(bridge).resolve();requests=bridge/'requests';responses=bridge/'responses'
    requests.mkdir(parents=True,exist_ok=True);responses.mkdir(parents=True,exist_ok=True)
    # O_EXCL prevents two workers handling the same queue. Ctrl+C removes the lock.
    lock=bridge/'worker.lock'
    try: fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError: raise SystemExit('Worker lock exists. Stop the old worker; remove worker.lock only if it has exited.')
    os.write(fd,str(os.getpid()).encode());os.close(fd)
    worker=Worker()
    print('VisualMatch 1.4 worker READY: '+str(bridge),flush=True)
    try:
        while True:
            for path in sorted(requests.glob('*.json')):
                if not re.fullmatch(r'[A-Za-z0-9_-]+',path.stem): continue
                dest=responses/path.name
                if dest.exists(): continue
                try:
                    req=load(path)
                    if req.get('id')!=path.stem: raise ValueError('IPC request ID mismatch')
                    response={'ok':True,'id':path.stem,**worker.dispatch(req)}
                except Exception as exc:
                    response={'ok':False,'id':path.stem,'error':str(exc)}
                    with (bridge/'worker_errors.log').open('a',encoding='utf-8') as f: f.write(traceback.format_exc()+'\n')
                atomic_json(dest,response)
            time.sleep(.10)
    except KeyboardInterrupt: print('Worker stopped.',flush=True)
    finally: lock.unlink(missing_ok=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--bridge',type=Path,default=Path(__file__).resolve().parent.parent/'runtime')
    serve(ap.parse_args().bridge)
